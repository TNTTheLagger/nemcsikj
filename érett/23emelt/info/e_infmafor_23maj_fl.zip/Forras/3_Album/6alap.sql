SELECT nev, fenyid
FROM szemely, kapcsolo
WHERE id = szemid AND
…
