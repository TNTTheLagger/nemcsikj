﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace feladat4
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader sr = new StreamReader("mozi.be");
            int z = 0;
            string k = sr.ReadLine();
            string[] kk = k.Split(' ');
            int[] e = new int[3];
            for (int i = 0; i < 3; )
            {
                e[i]=Convert.ToInt32(kk[i]);
                i++;
            }
            int[] m = new int[e[1]];
            k=sr.ReadLine();
            string[] kkk= k.Split(' ');
            for (int i=0;i<e[1];)
            {
                m[i]= Convert.ToInt32(kkk[i]);
                i++;
            }
              int s =0;
              int[] er = new int[e[0]];
            for (int i=0; i <e[0]; )
            {
                s = 0;
                while (m[s] != i+1==true)
                {
                    s++;
                    if (s != e[1]==false)
                    {
                        break;
                    }
                }
                if (s != 0 && s != e[0])
                {
                    er[i] = s+1;
                } i++;
            }
            s = 0;
            int[] me = new int[e[0]];
            do
            {
                me[s] = er[s];
                s++;
            }
            while ((m[s] != s-1) );
            
           for (int i=0; s<e[0];)
           {
               z = 0;
               i = 0;
               while(m[z]==(s))
               {
                   z++;
                   i++;
               }
               me[s] = (m[i] + e[2]);
               
               s++;
               
            }
           StreamWriter sw = new StreamWriter("mozi.ki");
           sw.WriteLine(e[0]);
           for (int i = 0; i < e[0]; )
           {
               sw.WriteLine(me[i]+" "+ (i+1));
               i++;
           }
           sw.Close();
            
        }
    }
}
