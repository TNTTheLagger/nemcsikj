﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Program1
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader sr = new StreamReader("fal.be");
            string k = sr.ReadLine();
            string[] kt = k.Split(' ');
            int[] elso= new int [2];
            for (int i = 0; i < 2; )
            {
                elso[i] = Convert.ToInt32(kt[i]);
                i++;
            }
            
            int[] a = new int[elso[1]];
            int[] b = new int[elso[1]];
            for (int i = 0; i < elso[1]; )
            {
                k = sr.ReadLine();
                a[i] = Convert.ToInt32(k);
                i++;
            }
            int y=1;
            int s =0;
          
            
            Console.WriteLine(b[3]);
                    Console.ReadLine();
        }
    }
}
