﻿/*
 * Készítette a SharpDevelop.
 * Felhasználó: ver45
 * Dátum: 2014.01.11.
 * Idő: 9:13
 * 
 * A sablon megváltoztatásához használja az Eszközök | Beállítások | Kódolás | Szabvány Fejlécek Szerkesztését.
 */
using System;
using System.IO;
using System.Collections.Generic;

namespace fal
{
	class Program
	{
		public static void Main(string[] args)
		{
			StreamWriter ki=new StreamWriter("fal.ki");
			StreamReader be=new StreamReader("fal.be");
			string [] line;string line2;
			int M=0; int N=0;
			line=be.ReadLine().Split(' ');
			N=Convert.ToInt32(line[0]);
			M=Convert.ToInt32(line[1]);
			int[] a=new int[M];
			int[] b=new int[N];int k=0;
			while(!be.EndOfStream)
			{
				line2=be.ReadLine();
				a[k]=Convert.ToInt32(line2);k++;
			}
			
			
			
			for(int i=0;i<N;i++)
				b[i]=0;
			
			for(int i=0;i<b.Length;i++)
			{
				for(int j=0;j<a.Length;j++)
				{
					if(a[j]==i+1 && b[i]==0)
						b[i]=1;
				}
			}
			
			int orh=0;
			for(int i=1;i<b.Length;i++)
			{
				if(b[i]==1 && b[i-1]==0 && b[i+1]==1)
					orh++;
			}
			int mindo=0; int [] c=new int[N]; int p=0;
			for(int i=1;i<b.Length;i++)
			{
				if(b[i]==0 && b[i-1]==0)
				{
					c[p]=i; p++; mindo++;
				}
			}
			
			
			for(int i=1;i<b.Length;i++)
			{
				if(b[i-1]==0 && b[i]==1)
					b[i-1]=1;
			}
			
			int orzsz=0;
			
			for(int i=1;i<b.Length;i++)
			{
				if(b[i]==1 && b[i-1]==0 && b[i+1]==1)
					orzsz++;
			}
			ki.WriteLine(orh);
			ki.WriteLine(orzsz);
			ki.WriteLine(mindo);
			ki.Close();
		}
	}	
		}
	