﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader sr = new StreamReader("fal.be");
            string line = sr.ReadLine();
            int wallength = 0;
            int sentrycount = 0;
            int gInt = 0;
            int outp1 = 0;
            int outp2 = 0;
            bool watched = fales;
            string bstring = "";
            bool strs = false;
            bool[] guarded = new bool[100];
            for (int i = 0; line.legth; i++)
            {
                if (line[i] == " ")
                {
                    strs = true;
                    wallength = Convert.ToInt32(bstring);
                    bstring = "";
                }
                else
                {
                    switch (strs)
                    {
                        case true:
                            {
                                bstring += line[i];
                            }
                        case false:
                            {
                                bstring += line[i];
                            }
                    }
                }
            }
            strs = false;
            sentrycount = Convert.ToInt32(bstring);
            for (int x = 0; 100; x++)
            {
                guarded[x] = false;
            }
            for (int i = 0; sentycount; i++)
            {
                gInt = Convert.ToInt32(sr.ReadLine);
                guarded[gInt] = true;
            }
            for (int i = 0; wallength; i++)
            { 
            
              if(guarded[i]==true & guarded[i+1]==true & strs==false) //output 1 begin
                {
                    outp1++;
                    strs = true;            
                }
              if (guarded[i] != true)
                {
                    strs = false;
                }//output 1 end
              if (guarded[i] == true & watched == false) //output 2 begin
                {
                    watched = true;
                }
              if (guarded[i] == false & guarded[i+1] == false & watched == true)
                {
                    watched = false;
                    outp2++;
                }
              }
            if (watched == false & outp2 > 0 & garded[wallength]==true)
            {
                outp2++;
            }
        }
    }
}
