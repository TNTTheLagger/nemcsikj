﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] line = new string[3];
            int x = 0;
            int y = 0;
            int a = 0;
            int b = 0;
            int[,] mtx = new int[1000, 1000];
            bool deniedn = false;
            bool step = false;
            int sor = 0;
            bool deniede = false;
            bool deniedd = false;
            bool deniedk = false;
            int oszlop = 0;
            int tabladb = 0;
            string path = "";
           
            int dist = 0;
            bool finished = false;
            StreamReader sr = new StreamReader("utcak.be");
            line = sr.ReadLine().Split(' ');
            sor = Convert.ToInt32(line[0]);
            oszlop = Convert.ToInt32(line[1]);
            tabladb = Convert.ToInt32(line[2]);
            for (int i = 1; i < tabladb; i++)
            {

                line = sr.ReadLine().Split(' ');
                for (int j = 0; j < 4; j++)
                {
                    mtx[i, j] = Convert.ToInt32(line[j]);

                }
            }
            try
            {
                line = sr.ReadLine().Split(' ');
            }
            catch {

                Console.WriteLine("Error while reading file");
            }
            a = Convert.ToInt32(line[0]); //kezdő pozíció
            b = Convert.ToInt32(line[1]); //kezdő pozíció
            x = Convert.ToInt32(line[2]); //végállás
            y = Convert.ToInt32(line[3]); //végállás

            while (finished == false)
            {
                Console.WriteLine(path);
                //Console.ReadKey();
                step = false;
                if (a == x & b == y)
                {
                    finished = true;
                }
                if (a == 1)
                {
                    deniedn = true;

                }
                if (b == 1)
                {
                    deniedd = true;

                }
                if (a == oszlop)
                {
                    deniedk = true;
                }
                if (b == sor)
                {
                    deniede = true;
                }
                if (a < x)
                {
                    for (int i = 0; i < tabladb; i++)//felfelé?
                    {
                        if (mtx[i, 1] == a & mtx[i, 2] == b & mtx[i, 3] == a + 1 & mtx[i, 4] == b)
                        {
                            deniede = true;
                        }

                    }

                }
                else
                {
                    a++;
                    step = true;
                    path += "E";
                    dist++;

                }
                if (b < y)
                {
                    for (int i = 0; i < tabladb; i++)//jobbra?
                    {
                        if (mtx[i, 1] == a & mtx[i, 2] == b & mtx[i, 3] == a + 1 & mtx[i, 4] == b)
                        {
                            deniedn = true;
                        }

                    }

                }
                else
                {
                    b++;
                    step = true;
                    path += "K";
                    dist++;

                }
                if (a > x)
                {
                    for (int i = 0; i < tabladb; i++)//lefelé?
                    {
                        if (mtx[i, 1] == a & mtx[i, 2] == b & mtx[i, 3] == a + 1 & mtx[i, 4] == b)
                        {
                            deniedd = true;
                        }

                    }

                }
                else
                {
                    a--;
                    step = true;
                    path += "D";
                    dist++;

                }
                if (b < y)
                {
                    for (int i = 0; i < tabladb; i++)//balra?
                    {
                        if (mtx[i, 1] == a & mtx[i, 2] == b & mtx[i, 3] == a + 1 & mtx[i, 4] == b)
                        {
                            deniedk = true;
                        }

                    }

                }
                else
                {
                    b--;
                    step = true;
                    path += "N";
                    dist++;

                }
                if (step == false)
                {
                    if (deniedd == true & deniede == true & deniedk == true)
                    {
                        path += "N";
                    }
                    else if (deniedd == true & deniede == true)
                    {
                        path += "K";

                    }
                    else if (deniedd == true)
                    {
                        path += "E";
                    }
                    else
                    {
                        path += "D";
                    }


                }

            }
            StreamWriter sw = new StreamWriter("utcak.ki");
            sw.WriteLine(dist);
            sw.WriteLine(path);
            sw.Close();
            Console.WriteLine(path);
            Console.WriteLine(a +" "+b+" "+x+" "+y);
            Console.ReadLine();

        }
    }
    }
