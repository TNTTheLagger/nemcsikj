﻿/*
 * Készítette a SharpDevelop.
 * Felhasználó: ver53
 * Dátum: 2014.01.11.
 * Idő: 9:09
 * 
 * A sablon megváltoztatásához használja az Eszközök | Beállítások | Kódolás | Szabvány Fejlécek Szerkesztését.
 */
using System;
using System.IO;
namespace fal
{
	class Program
	{
		public static void Main(string[] args)
		{
			StreamReader be=new StreamReader("fal.be");
			StreamWriter ki=new StreamWriter("fal.ki");
			string [] s=be.ReadLine().Split(' ');
			int N=int.Parse(s[0]);
			int M=int.Parse(s[1]);
			int [] a=new int[M+1];
			for(int i=0;i<M;i++)
				a[i]=int.Parse(be.ReadLine());
			int csere=0;
			for(int i=0;i<M;i++)
				for(int j=0;j<M;j++)
					if(a[j]>a[i])
					{
					csere=a[j];
					a[j]=a[i];
					a[i]=csere;
					}
			//a feladat//
			int jel=0,db=0;
			a[M]=0;
			for(int i=0;i<M;i++)
			{
				if(a[i]+1==a[i+1])
					jel=1;
				else
				if(jel==1)
				{
				db++;
				jel=0;
				}
			}
			ki.WriteLine(db);
		 	//a feladat vége//
		 	//b feladat//
			jel=0;
			db=0;
			for(int i=0;i<M;i++)
			{
				if(a[i]+1==a[i+1] || a[i]+2==a[i+1])
					jel=1;
				else
				if(jel==1)
				{
				db++;
				jel=0;
				}
			}
			ki.WriteLine(db);
			//b feladat vége//
			//c feladat//
			db=(a[0]-1)/2;
			for(int i=0;i<M;i++)
				if(a[i+1]!=0 && a[i+1]-a[i]!=2)
					db=db+(a[i+1]-a[i])/2;
			ki.WriteLine(db);
			ki.Close();
			//c feladat vége//
			
		}
	}
}