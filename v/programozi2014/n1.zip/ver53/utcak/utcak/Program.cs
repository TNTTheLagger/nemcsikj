﻿/*
 * Készítette a SharpDevelop.
 * Felhasználó: ver53
 * Dátum: 2014.01.11.
 * Idő: 10:10
 * 
 * A sablon megváltoztatásához használja az Eszközök | Beállítások | Kódolás | Szabvány Fejlécek Szerkesztését.
 */
using System;
using System.IO;
namespace utcak
{
	class Program
	{
		public static void Main(string[] args)
		{
			StreamReader be=new StreamReader("utcak.be");
			StreamWriter ki=new StreamWriter("utcak.ki");
			string [] s=be.ReadLine().Split(' ');
			int sor=int.Parse(s[0]);
			int oszl=int.Parse(s[1]);
			int tabl=int.Parse(s[2]);
			int [,] a=new int[sor,oszl];
			a.GetValue(0,0);
			int jel=1;
			for(int i=0;i<tabl;i++)
			{
			string [] sz=be.ReadLine().Split(' ');
			int sz1=int.Parse(sz[0]);
			int sz2=int.Parse(sz[1]);
			int sz3=int.Parse(sz[2]);
			int sz4=int.Parse(sz[3]);
			a[sor-sz1,sz2-1]=1;	
			a[sor-sz3,sz4-1]=2;
			}
			string [] ST=be.ReadLine().Split(' ');
			int [] st=new int[2];
			int [] fs=new int[2];
			st[0]=sor-int.Parse(ST[0]);
			st[1]=int.Parse(ST[1])-1;
			fs[0]=sor-int.Parse(ST[2]);
			fs[1]=int.Parse(ST[3])-1;
			int db=0;
			while(st[0]!=fs[0] || st[1]!=fs[1])
			{
				if(a[st[0],st[1]]+1!=a[st[0]-1,st[1]] && st[0]<fs[0] && st[0]!=0)
				{
					st[0]--;
					db++;
				}
				else
					if(a[st[0],st[1]]+1!=a[st[0],st[1]-1] && st[0]>fs[0] && st[0]!=sor-1)
				{
					st[0]++;
					db++;
				}
				if(a[st[0],st[1]]+1!=a[st[0],st[1]+1] && st[1]<fs[1] && st[1]!=0)
				{
					st[1]--;
					db++;
				}
				else
				if(a[st[0],st[1]]+1!=a[st[0],st[1]+1] && st[1]>fs[1] && st[1]!=oszl)
				{
					st[1]++;
					db++;
				}
			 }
			ki.WriteLine(db);
			ki.Close();
		}
	}
}