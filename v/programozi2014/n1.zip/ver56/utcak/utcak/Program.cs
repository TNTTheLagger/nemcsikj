﻿/*
 * Készítette a SharpDevelop.
 * Felhasználó: ver55
 * Dátum: 2014.01.11.
 * Idő: 9:44
 * 
 * A sablon megváltoztatásához használja az Eszközök | olvasállítások | Kódolás | Szabvány Fejlécek Szerkesztését.
 */
using System;
using System.IO;
using System.Collections.Generic;

namespace utcak
{
		
	class Program
	{
         static int N, M, T;
        static Pont kezdet, cel;
		static int[,] ido; static List<char>[,] ut;
        static List<Pont> honnan = new List<Pont>(), hova = new List<Pont>();
		
		public static void Main(string[] args)
		{
			StreamReader olvas = new StreamReader("utcak.olvas");
            String[] line = olvas.ReadLine().Split(' ');
            N = int.Parse(line[0]); M = int.Parse(line[1]); T = int.Parse(line[2]);
			ido = new int[N, M]; ut = new List<char>[N, M]; ut.Initialize();
			Pont p, q;
			for(int i = 0; i < T; i ++)
			{
                line = olvas.ReadLine().Split(' ');
                p=new Pont(int.Parse(line[0])-1, int.Parse(line[1])-1);
                q = new Pont(int.Parse(line[2])-1, int.Parse(line[3])-1);
				honnan.Add(p); hova.Add(q);
			}
			
			for(int i = 0; i < N; i ++)
			{
				for(int j = 0; j < M; j ++)
					ido[i, j] = int.MaxValue - 1;
			}
			ido[kezdet.X, kezdet.Y] = 0; ut[kezdet.X, kezdet.Y] = new List<char>();
			
			Pont aktualis;
            List<Pont> volt = new List<Pont>();
			Queue<Pont> sor = new Queue<Pont>(); 
            sor.Enqueue(kezdet);
			while(sor.Count != 0)
			{
				aktualis = sor.Dequeue();
				if( volt.Contains(new Pont(aktualis.X, aktualis.Y - 1))==false && csinal(aktualis, 'N'))
				{
                    volt.Add(new Pont(aktualis.X, aktualis.Y - 1));
                    sor.Enqueue(new Pont(aktualis.X, aktualis.Y - 1));
				}
				if( volt.Contains(new Pont(aktualis.X, aktualis.Y + 1))==false && csinal(aktualis, 'K'))
				{
					sor.Enqueue(new Pont(aktualis.X, aktualis.Y + 1));
					volt.Add(new Pont(aktualis.X, aktualis.Y + 1));
				}
				if(volt.Contains(new Pont(aktualis.X + 1, aktualis.Y))==false &&csinal(aktualis, 'E'))
				{
					volt.Add(new Pont(aktualis.X + 1, aktualis.Y));
                    sor.Enqueue(new Pont(aktualis.X + 1, aktualis.Y));
				}
				if(volt.Contains(new Pont(aktualis.X - 1, aktualis.Y))==false && csinal(aktualis, 'D'))
				{
					sor.Enqueue(new Pont(aktualis.X - 1, aktualis.Y));
					volt.Add(new Pont(aktualis.X - 1, aktualis.Y));
				}
				
				
				int min = int.MaxValue; 
                List<char> alaput = ut[aktualis.X, aktualis.Y]; 
                char irany = 'G';
				if(ido[aktualis.X, aktualis.Y] < min)
				{
					min = ido[aktualis.X, aktualis.Y];
				}
                if (aktualis.Y < M - 1 && ido[aktualis.X, aktualis.Y + 1] + 1 < min)
                {
                    irany = 'N';
                    alaput = ut[aktualis.X, aktualis.Y + 1];
                    min = ido[aktualis.X, aktualis.Y + 1] + 1;

                }
				if(aktualis.X < N - 1 && ido[aktualis.X + 1, aktualis.Y] + 1 < min)
				{
                    irany = 'D';
                    alaput = ut[aktualis.X + 1, aktualis.Y]; 
                    min = ido[aktualis.X + 1, aktualis.Y] + 1;
			                    
				}
				if (aktualis.Y > 0 && ido[aktualis.X, aktualis.Y - 1] + 1 < min)
                {
                    irany = 'K';
                    alaput = ut[aktualis.X, aktualis.Y - 1];
                    min = ido[aktualis.X, aktualis.Y - 1] + 1;

                }
				if(aktualis.X > 0 && ido[aktualis.X - 1, aktualis.Y] + 1 < min)
				{
                    irany = 'E';
                    alaput = ut[aktualis.X - 1, aktualis.Y]; 
                    min = ido[aktualis.X - 1, aktualis.Y] + 1;
					
				}
				if(irany != 'G')
				{
					ido[aktualis.X, aktualis.Y] = min;
					alaput.Add(irany);
					ut[aktualis.X, aktualis.Y] = new List<char>(alaput);
				}
			}
            olvas.Close();
			StreamWriter ir = new StreamWriter("utcak.ki"); Console.SetOut(ir as TextWriter);
			ut[cel.X, cel.Y].RemoveAt(0); ut[cel.X, cel.Y].RemoveAt(ut[cel.X, cel.Y].Count - 1);
			Console.WriteLine(ido[cel.X, cel.Y]); 
            Console.Write(ut[cel.X, cel.Y].ToArray());
			ir.Close();
		}
		
		static bool csinal(Pont P, char irany)
		{
			if(irany == 'N')
			{
				if(P.Y == 0)
					return false;
				for(int i = 0; i < honnan.Count; i ++)
					if(honnan[i].Equals(P) && hova[i].Equals(new Pont(P.X, P.Y - 1)))
						return false;
			}
			else if(irany == 'D')
			{
				if(P.X == 0)
					return false;
				for(int i = 0; i < honnan.Count; i ++)
					if(honnan[i].Equals(P) && hova[i].Equals(new Pont(P.X - 1, P.Y)))
			  	        return false;
			}
			else if(irany == 'K')
			{
				if(P.Y == M - 1)
					return false;
				for(int i = 0; i < honnan.Count; i ++)
					if(honnan[i].Equals(P) && hova[i].Equals(new Pont(P.X, P.Y + 1)))
						return false;
			}
			else if(irany == 'E')
			{
				if(P.X == N - 1)
					return false;
				for(int i = 0; i < honnan.Count; i ++)
					if(honnan[i].Equals(P) && hova[i].Equals(new Pont(P.X + 1, P.Y)))
						return false;
			}
			return true;
		}
	}
         
    public class Pont
    {
		public int X, Y;
		public Pont(int x, int y)
		{
			X = x; Y = y;
		}
		public override bool Equals(object p)
		{
			if(this.X == (p as Pont).X && this.Y == (p as Pont).Y)
				return true;
			return false;
		}
     }
}