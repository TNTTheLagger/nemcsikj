﻿/*
 * Készítette a SharpDevelop.
 * Felhasználó: ver55
 * Dátum: 2014.01.11.
 * Idő: 13:06
 * 
 * A sablon megváltoztatásához használja az Eszközök | Beállítások | Kódolás | Szabvány Fejlécek Szerkesztését.
 */
using System;
using System.IO;
using System.Collections.Generic;

namespace mozi
{
	class Program
	{
		static int M, N, K, L = 0;
		static int[] igenyek, helyek;
		static bool[] vanhely;
		public static void Main(string[] args)
		{
			StreamReader be = new StreamReader("mozi.be"); Console.SetIn(be as TextReader);
			string temp = Console.ReadLine();
			M = int.Parse(temp.Split(' ')[0]); N = int.Parse(temp.Split(' ')[1]); K = int.Parse(temp.Split(' ')[2]);
			temp = Console.ReadLine();
			be.Close();
			igenyek = new int[N]; vanhely = new bool[M]; helyek = new int[M];
			for(int i = 0; i < N; i ++)
				igenyek[i] = int.Parse(temp.Split(' ')[i]) - 1;
			for(int i = 0; i < M; i ++)
			{
				vanhely[i] = true; helyek[i] = -1;
			}
			
			for(int i = 0; i < N; i ++)
			{
				for(int j = igenyek[i]; j <= igenyek[i] + K && j < M; j ++)
				{
					if(vanhely[j])
					{
						vanhely[j] = false;
						helyek[j] = i + 1; L ++;
						break;
					}
				}
			}
			
			StreamWriter ki = new StreamWriter("mozi.ki"); Console.SetOut(ki as TextWriter);
			Console.WriteLine(L);
			for(int i = 0; i < M - 1; i ++)
			{
				if(helyek[i] != -1)
					Console.WriteLine("{0} {1}", helyek[i], i + 1);
			}
			if(helyek[M - 1] != -1)
				Console.Write("{0} {1}", helyek[M - 1], M);
			ki.Close();
		}
	}
}