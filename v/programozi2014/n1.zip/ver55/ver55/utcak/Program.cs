﻿/*
 * Készítette a SharpDevelop.
 * Felhasználó: ver55
 * Dátum: 2014.01.11.
 * Idő: 9:44
 * 
 * A sablon megváltoztatásához használja az Eszközök | Beállítások | Kódolás | Szabvány Fejlécek Szerkesztését.
 */
using System;
using System.IO;
using System.Collections.Generic;

namespace utcak
{
	public class Point
	{
		public int X, Y;
		public Point(int x, int y)
		{
			X = x; Y = y;
		}
		
		public override bool Equals(object p)
		{
			if(this.X == (p as Point).X && this.Y == (p as Point).Y)
				return true;
			return false;
		}
	}
	
	class Program
	{
		static int N, M, T;
		static Point kezd, cel;
		static List<Point> honnan = new List<Point>(), hova = new List<Point>();
		static int[,] ido; static List<char>[,] ut;
		
		public static void Main(string[] args)
		{
			StreamReader be = new StreamReader("utcak.be"); Console.SetIn(be as TextReader);
			string temp = Console.ReadLine();
			N = int.Parse(temp.Split(' ')[0]); M = int.Parse(temp.Split(' ')[1]); T = int.Parse(temp.Split(' ')[2]);
			ido = new int[N, M]; ut = new List<char>[N, M]; ut.Initialize();
			
			Point p, q;
			for(int i = 0; i < T; i ++)
			{
				temp = Console.ReadLine();
				p = new Point(int.Parse(temp.Split(' ')[0]) - 1, int.Parse(temp.Split(' ')[1]) - 1);
				q = new Point(int.Parse(temp.Split(' ')[2]) - 1, int.Parse(temp.Split(' ')[3]) - 1);
				honnan.Add(p); hova.Add(q);
			}
			temp = Console.ReadLine();
			kezd = new Point(int.Parse(temp.Split(' ')[0]) - 1, int.Parse(temp.Split(' ')[1]) - 1);
			cel = new Point(int.Parse(temp.Split(' ')[2]) - 1, int.Parse(temp.Split(' ')[3]) - 1);
			be.Close();
			
			for(int i = 0; i < N; i ++)
			{
				for(int j = 0; j < M; j ++)
					ido[i, j] = int.MaxValue - 1;
			}
			ido[kezd.X, kezd.Y] = 0; ut[kezd.X, kezd.Y] = new List<char>();
			
			Point most;
			Queue<Point> sor = new Queue<Point>(); sor.Enqueue(kezd);
			List<Point> volt = new List<Point>();
			while(sor.Count != 0)
			{
				most = sor.Dequeue();
				if(cango(most, 'N') && !volt.Contains(new Point(most.X, most.Y - 1)))
				{
					sor.Enqueue(new Point(most.X, most.Y - 1));
					volt.Add(new Point(most.X, most.Y - 1));
				}
				if(cango(most, 'K') && !volt.Contains(new Point(most.X, most.Y + 1)))
				{
					sor.Enqueue(new Point(most.X, most.Y + 1));
					volt.Add(new Point(most.X, most.Y + 1));
				}
				if(cango(most, 'E') && !volt.Contains(new Point(most.X + 1, most.Y)))
				{
					sor.Enqueue(new Point(most.X + 1, most.Y));
					volt.Add(new Point(most.X + 1, most.Y));
				}
				if(cango(most, 'D') && !volt.Contains(new Point(most.X - 1, most.Y)))
				{
					sor.Enqueue(new Point(most.X - 1, most.Y));
					volt.Add(new Point(most.X - 1, most.Y));
				}
				
				
				int min = int.MaxValue; List<char> alaput = ut[most.X, most.Y]; char irany = 'G';
				if(ido[most.X, most.Y] < min)
				{
					min = ido[most.X, most.Y];
				}
				if(most.X < N - 1 && ido[most.X + 1, most.Y] + 1 < min)
				{
					min = ido[most.X + 1, most.Y] + 1;
					alaput = ut[most.X + 1, most.Y]; irany = 'D';
				}
				if(most.Y < M - 1 && ido[most.X, most.Y + 1] + 1 < min)
				{
					min = ido[most.X, most.Y + 1] + 1;
					alaput = ut[most.X, most.Y + 1]; irany = 'N';
				}
				if(most.X > 0 && ido[most.X - 1, most.Y] + 1 < min)
				{
					min = ido[most.X - 1, most.Y] + 1;
					alaput = ut[most.X - 1, most.Y]; irany = 'E';
				}
				if(most.Y > 0 && ido[most.X, most.Y - 1] + 1 < min)
				{
					min = ido[most.X, most.Y - 1] + 1;
					alaput = ut[most.X, most.Y - 1]; irany = 'K';
				}
				
				if(irany != 'G')
				{
					ido[most.X, most.Y] = min;
					alaput.Add(irany);
					ut[most.X, most.Y] = new List<char>(alaput);
				}
			}
			
			StreamWriter ki = new StreamWriter("utcak.ki"); Console.SetOut(ki as TextWriter);
			ut[cel.X, cel.Y].RemoveAt(0); ut[cel.X, cel.Y].RemoveAt(ut[cel.X, cel.Y].Count - 1);
			Console.WriteLine(ido[cel.X, cel.Y]); Console.Write(ut[cel.X, cel.Y].ToArray());
			ki.Close();
		}
		
		static bool cango(Point P, char direction)
		{
			if(direction == 'N')
			{
				if(P.Y == 0)
					return false;
				for(int i = 0; i < honnan.Count; i ++)
				{
					if(honnan[i].Equals(P) && hova[i].Equals(new Point(P.X, P.Y - 1)))
						return false;
				}
			}
			else if(direction == 'D')
			{
				if(P.X == 0)
					return false;
				for(int i = 0; i < honnan.Count; i ++)
				{
					if(honnan[i].Equals(P) && hova[i].Equals(new Point(P.X - 1, P.Y)))
						return false;
				}
			}
			else if(direction == 'K')
			{
				if(P.Y == M - 1)
					return false;
				for(int i = 0; i < honnan.Count; i ++)
				{
					if(honnan[i].Equals(P) && hova[i].Equals(new Point(P.X, P.Y + 1)))
						return false;
				}
			}
			else if(direction == 'E')
			{
				if(P.X == N - 1)
					return false;
				for(int i = 0; i < honnan.Count; i ++)
				{
					if(honnan[i].Equals(P) && hova[i].Equals(new Point(P.X + 1, P.Y)))
						return false;
				}
			}
			return true;
		}
	}
}