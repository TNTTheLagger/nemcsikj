﻿/*
 * Készítette a SharpDevelop.
 * Felhasználó: ver55
 * Dátum: 2014.01.11.
 * Idő: 9:03
 * 
 * A sablon megváltoztatásához használja az Eszközök | Beállítások | Kódolás | Szabvány Fejlécek Szerkesztését.
 */
using System;
using System.IO;

namespace fal
{
	class Program
	{
		static int N, M, vedett = 0, orzott = 0, kellmeg = 0;
		static bool[] fal, orzottresz;
		
		public static void Main(string[] args)
		{
			StreamReader be = new StreamReader("fal.be"); Console.SetIn(be as TextReader);
			string temp = Console.ReadLine();
			N = int.Parse(temp.Split(' ')[0]); M = int.Parse(temp.Split(' ')[1]);
			fal = new bool[N]; orzottresz = new bool[N - 1];
			for(int i = 0; i < M; i ++)
				fal[int.Parse(Console.ReadLine()) - 1] = true;
			be.Close();
			
			bool ved = false, or = false;
			for(int i = 0; i < N - 1; i ++)
			{
				if(fal[i] && fal[i + 1])
				{
					ved = true;
					orzottresz[i] = true;
				}
				else if(ved)
				{
					vedett ++;
					ved = false;
				}
				if(fal[i] || fal[i + 1])
				{
					or = true;
					orzottresz[i] = true;
				}
				else if(or)
				{
					orzott ++;
					or = false;
				}
			}
			if(ved)
				vedett ++;
			if(or)
				orzott ++;
			
			for(int i = 0; i < N - 2; i ++)
			{
				if(!fal[i] && !fal[i + 1] && !fal[i + 2])
				{
					kellmeg ++;
					fal[i + 1] = true;
				}
			}
			for(int i = 0; i < N - 1; i ++)
			{
				if(!fal[i] && !fal[i + 1])
				{
					kellmeg ++;
					fal[i] = true;
				}
			}
			
			StreamWriter ki = new StreamWriter("fal.ki"); Console.SetOut(ki as TextWriter);
			Console.WriteLine(vedett); Console.WriteLine(orzott); Console.Write(kellmeg);
			ki.Close();
		}
	}
}