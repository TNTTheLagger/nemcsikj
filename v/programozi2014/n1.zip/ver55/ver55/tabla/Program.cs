﻿/*
 * Készítette a SharpDevelop.
 * Felhasználó: ver55
 * Dátum: 2014.01.11.
 * Idő: 11:26
 * 
 * A sablon megváltoztatásához használja az Eszközök | Beállítások | Kódolás | Szabvány Fejlécek Szerkesztését.
 */
using System;
using System.IO;
using System.Collections.Generic;

namespace tabla
{
	class Program
	{
		static List<string> eredeti; static List<char> rovid = new List<char>();
		static long szintek = 1;
		public static void Main(string[] args)
		{
			StreamReader be = new StreamReader("tabla.be"); Console.SetIn(be as TextReader);
			Console.ReadLine(); eredeti = new List<string>(Console.ReadLine().Split(' ')); be.Close();
			be.Close();
			
			for(int i = 0; i < eredeti.Count; i ++)
			{
				if(eredeti[i] == "0" || eredeti[i] == "1")
					szintek ++;
				else if(eredeti[i] == "2")
					szintek --;
			}
			
			//minden pontot a leggyorsabban balra le és jobbra le lépésekkel lehet elérni az első szint pontjából
			bool left = true; long szintmost = 0, hol = 0, szinthossz = 1;
			for(int i = 0; i < eredeti.Count; i ++)
			{
				
				
				if(eredeti[i] == "0")
				{
					rovid.Add('0');
					left = true;
					szintmost ++;
				}
				else if(eredeti[i] == "1")
				{
					rovid.Add('1');
					left = false;
					szintmost ++;
				}
				else if(eredeti[i] == "2")
				{
					rovid.RemoveAt(rovid.Count - 1);
					left = rovid.Count == 0 ? true : rovid[rovid.Count - 1] == '0';
					szintmost --;
				}
				else if(eredeti[i] == "3")
				{
					//if(!left)
					//	rovid[rovid.Count - 1] = '0';
					//else
					{
						//kiszámítom, hanyadik elemnél járok és mennyiből
						szinthossz = (long)Math.Pow(2, szintmost);
						for(int j = 1; j <= rovid.Count; j ++)
						{
							if(rovid[j - 1] == '1')
							{
								hol += (long)Math.Pow(2, szintmost - j);
							}
						}
						int k = 0;
						while(szinthossz != 1)
						{
							szinthossz /= 2;
							rovid[k] = ((rovid[k] == '0' && hol < szinthossz) || (rovid[k] == '1' && hol >= szinthossz)) ? rovid[k] : (rovid[k] == '0' ? '1' : '0');
							k ++;
						}
					}
				}
				else if(eredeti[i] == "4")
				{
					//if(left)
					//	rovid[rovid.Count - 1] = '1';
					//else
					{
						szinthossz = (long)Math.Pow(2, szintmost);
						for(int j = 1; j <= rovid.Count; j ++)
						{
							if(rovid[j - 1] == '1')
							{
								hol += (long)Math.Pow(2, szintmost - j);
							}
						} hol ++;
						int k = 0;
						while(szinthossz != 1)
						{
							szinthossz /= 2;
							rovid[k] = ((rovid[k] == '0' && hol < szinthossz) || (rovid[k] == '1' && hol >= szinthossz)) ? rovid[k] : (rovid[k] == '0' ? '1' : '0');
							k ++;
						}
					}
				}
			}
			
			StreamWriter ki = new StreamWriter("tabla.ki"); Console.SetOut(ki as TextWriter);
			Console.WriteLine(rovid.Count);
			for(int i = 0; i < rovid.Count; i ++)
				Console.Write(i - 1 == rovid.Count ? "{0}" : "{0} ", rovid[i]);
			ki.Close();
		}
	}
}