﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Numerics;

namespace lepes
{
    class lepes
    {
        static int K;
        static List<int> t;
        static BigInteger S = 1, E = 1;

        static void Main(string[] args)
        {
            StreamReader fbe = new StreamReader("lepes.be");
            K = int.Parse(fbe.ReadLine().Trim());
            t = fbe.ReadLine().Trim().Split(' ').Select(x => int.Parse(x)).ToList();

            foreach (int p in t)
            {
                switch (p)
                {
                    case 0:
                        S++;
                        E = E * 3 - 2;
                        break;
                    case 1:
                        S++;
                        E = E * 3 - 1;
                        break;
                    case 2:
                        S++;
                        E = E * 3;
                        break;
                    case 3:
                        S--;
                        if (E % 3 == 0)
                            E = E / 3;
                        else
                            E = E / 3 + 1;
                        break;
                    case 4:
                        E--;
                        break;
                    case 5:
                        E++;
                        break;
                }
            }

            //vissza: csak fel
            Stack<BigInteger> mo = new Stack<BigInteger>();
            while (S != 1 || E != 1)
            {
                S--;
                if(E%3==0)
                        mo.Push(2);
                if(E%3==1)
                        mo.Push(0);
                if(E%3==2)
                        mo.Push(1);
                if (E % 3 == 0)
                    E = E / 3;
                else
                    E = E / 3 + 1;
            }

            StreamWriter fki = new StreamWriter("lepes.ki");
            fki.WriteLine(mo.Count);
            while (mo.Count > 0)
                fki.Write("{0} ", mo.Pop());
            fki.Close();
        }
    }
}
