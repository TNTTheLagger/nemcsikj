﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace gepek
{
    class gepek
    {
        static int[] p;
        static List<Tuple<int, int>> h, h2;
        static List<Tuple<int, int, int>> mo = new List<Tuple<int, int, int>>();
        static void Main(string[] args)
        {
            StreamReader fbe = new StreamReader("gepek.be");
            p = fbe.ReadLine().Trim().Split(' ').Select(x => int.Parse(x)).ToArray();
            h = fbe.ReadLine().Trim().Split(' ').Select((x, i) => Tuple.Create(int.Parse(x), i + 1)).OrderBy(x => x).ToList();
            fbe.Close();

            int aktido = 1;
            int maxGep = 1;

            h2 = new List<Tuple<int, int>>(h);
            do
            {
                if (aktido <= h[0].Item1)
                {
                    for (int i = 1; i <= maxGep; i++)
                    {
                        if (h.Count > 0)
                        {
                            mo.Add(Tuple.Create(h[0].Item2, aktido, i));
                            h.RemoveAt(0);
                        }
                    }
                    //mo.Add(Tuple.Create(h[0].Item2, aktido, 1));//munka sorszama, ido, melyik gep
                    //h.RemoveAt(0);
                }
                else
                {
                    //int prevmaxgep = maxGep;
                    //maxGep = Math.Max(h.Where(x => x.Item1 == h[0].Item1).Count(), maxGep);
                    //if (maxGep > prevmaxgep)
                    //{
                    //    //újrakezd
                    //    aktido = 1;
                    //    mo.Clear();
                    //    h = new List<Tuple<int, int>>(h2);
                    //}

                    //nem tudjuk hova tenni a feladatot, mert az határidő > mint az akt. idő --> kell még egy gép
                    //újrakezdjük az egészet
                    maxGep++;
                    aktido = 0;
                    mo.Clear();
                    h = new List<Tuple<int, int>>(h2);
                    /*
                    for (int i = 1; i <= maxGep; i++)
                    {
                        if (h.Count > 0)
                        {
                            mo.Add(Tuple.Create(h[0].Item2, aktido, i));
                            h.RemoveAt(0);
                        }
                    }*/
                }
                aktido++;
            } while (h.Count > 0);

            StreamWriter fki = new StreamWriter("gepek.ki");
            fki.WriteLine(maxGep);
            foreach (var item in mo.OrderBy(x => x.Item1))
            {
                fki.WriteLine("{0} {1}", item.Item2, item.Item3);
            }
            fki.Close();
            // Console.ReadLine();
        }
    }
}
