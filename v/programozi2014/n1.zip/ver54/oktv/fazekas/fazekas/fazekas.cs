﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace fazekas
{
    class Program
    {
        static void megoldas(int N, int[] idok, int K, int[] elozo, int egszam, int[,] megold)
        {
            int index = N;
            while (index > 0)
            {
                int t1;
                int t2;
                egetes_sep(idok, elozo[index], index, K, out t1, out t2);

                for (int i = elozo[index]; i <= index; i++)
                {
                    megold[i, 0] = egszam;
                    if (idok[i] <= t2)
                        megold[i, 1] = 2;
                    else
                        megold[i, 1] = 1;
                }

                egszam--;
                index = elozo[index] - 1;
            }
        }

        static void egetes_sep(int[] idok, int A, int B, int K, out int t1, out int t2)
        {
            var eget_ido = idok.Skip(A).Take(B - A + 1).ToArray();
            Array.Sort(eget_ido);
            t1 = eget_ido[eget_ido.Length - 1];
            t2 = eget_ido[0];
            if (eget_ido.Length > K)
                t2 = eget_ido[eget_ido.Length - 1 - K];
        }

	static int egetes(int[] idok, int A, int B, int K)
        {
            var eget_ido = idok.Skip(A).Take(B - A + 1).ToArray();
            Array.Sort(eget_ido);
            int t1 = eget_ido[eget_ido.Length - 1];
            int t2 = eget_ido[0];
            if(eget_ido.Length > K)
                t2 = eget_ido[eget_ido.Length - 1 - K];
            return t1 + t2;
        }

       

        static void Main(string[] args)
        {
            
	    static StreamReader fbe = new StreamReader("fazekas.be");
	    static StreamWriter fki = new StreamWriter("fazekas.ki");
            int N, K;
            {
                int[] vals = fbe.ReadLine().Split(' ').Select(e => int.Parse(e)).ToArray();
                N = vals[0];
                K = vals[1];
            }
            int K2 = K * 2;
            int[] idok = new int[] { 0 }.Concat(fbe.ReadLine().Split(' ').Select(e => int.Parse(e))).ToArray();
            int[] elozo = new int[N + 1];
	    int[] opt = new int[N + 1];
            int[] egszam = new int[N + 1];

            for (int i = 2; i <= N; i++)
            {
                opt[i] = int.MaxValue;
                for (int j = 1; j < K2 && i - j > 0; j++)
                {
                    if (i - j == 2) continue;
                    int new_opt = opt[i - j - 1] + egetes(idok, i - j, i, K);
                    if (new_opt < opt[i])
                    {
                        opt[i] = new_opt;
                        egszam[i] = egszam[i - j - 1] + 1;
                        elozo[i] = i - j;
                    }
                }
            }
            fbe.Close();
            int[,] megold = new int[N + 1, 2];
            megoldas(N, idok, K, elozo, egszam[N], megold);
            fki.WriteLine(opt[N]);
            for (int i = 1; i <= N; i++)
            {
                fki.WriteLine("{0} {1}", megold[i, 0], megold[i, 1]);
            }
            fki.Close();
        }
    }
}
