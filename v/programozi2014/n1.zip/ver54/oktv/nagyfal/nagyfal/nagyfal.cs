﻿using System;
using System.IO;
using System.Linq;

namespace nagyfal
{
    class nagyfal
    {
        static int[] p;
        static int[] t;
        static int[] t2, t3;//c,d

        public static void Main(string[] args)
        {
            StreamReader fbe = new StreamReader("nagyfal.be");
            p = fbe.ReadLine().Trim().Split(' ').Select(x => int.Parse(x)).ToArray();
            t = new int[101];
            t2 = new int[101];
            t3 = new int[101];
            int fel = 0;
            for (int i = 0; i < p[1]; i++)
            {
                int s = int.Parse(fbe.ReadLine().Trim());
                t[s]++;
                if (t[s] > 1) fel++;//felesleg
                t2[s]++;
                t3[s]++;
            }
            fbe.Close();
            int a = 0, b = 0, c = 0, d = 0;


            for (int i = 0; i < p[0]; i++)
            {
                if (t[i] == 0 && t[i + 1] > 0)//őrzött kezdődik
                {
                    int db = 0;
                    bool vedettKezd = false;
                    while (!(t[i] > 0 && t[i + 1] == 0) && i < p[0])//tudom, De Morgan...
                    {
                        db++;
                        if (db == 2) b++;
                        i++;
                        if (!vedettKezd && t[i] > 0 && t[i + 1] > 0)
                        {
                            a++;
                            vedettKezd = true;
                        }
                    }
                }
            }

            //c
            int fel2 = fel;
            while (fel > 0)
            {
                bool van = false;
                for (int i = 1; i < p[0]; i++)
                {
                    if (fel == 0) break;
                    if (t2[i] > 0 && t2[i + 1] == 0 && t2[i + 2] > 0)//védetté tehető, i+1-be kell
                    {
                        t2[i + 1] = 1;
                        fel--;
                        c++;
                        //if (t2[i + 2] > 0)//az utána lévő is védett lesz
                            c++;
                        van = true;
                    }
                }
                if (!van)
                {
                    van = false;
                    for (int i = 1; i < p[0]; i++)
                    {
                        if (fel == 0) break;
                        if (t2[i] > 0 && t2[i + 1] == 0)//védetté tehető, i+1-be kell
                        {
                            t2[i + 1] = 1;
                            fel--;
                            c++;
                            van = true;
                        }
                    }

                    if (!van)
                    {
                        for (int i = 1; i < p[0]; i++)
                        {
                            if (fel == 0) break;
                            if (t2[i] == 0 && t2[i + 1] > 0)//védetté tehető, i-be kell
                            {
                                t2[i] = 1;
                                fel--;
                                c++;
                            }
                        }
                    }
                }
            }

            //d
            fel = fel2;
            bool elsovel_nem_volt = false;
            bool masodikkal_nem_volt;
            while (fel > 0)
            {
                if (!elsovel_nem_volt)
                {
                    elsovel_nem_volt = true;
                    for (int i = 1; i < p[0]; i++)
                    {
                        if (fel == 0) break;
                        if (t3[i] == 0 && t3[i + 1] == 0 && t3[i - 1] == 0)//őrzötté tehető
                        {
                            t3[i] = 1;
                            d++;
                            if (i > 1) d++;//mert mindkét oldalt van
                            fel--;
                            elsovel_nem_volt=false;
                        }
                    }
                }
                if (elsovel_nem_volt)
                {
                    masodikkal_nem_volt=true;
                    for (int i = 1; i < p[0]; i++)
                    {
                        if (fel == 0) break;
                        if (t[i]>0 && t3[i + 1] == 0 && t3[i+2]==0)//őrzötté tehető
                        {
                            t3[i + 1] = 1;
                            fel--;
                            d++;
                            masodikkal_nem_volt=false;
                        }
                    }
                    if(masodikkal_nem_volt) break;
                }
            }

            StreamWriter fki = new StreamWriter("nagyfal.ki");
            fki.WriteLine(a);
            fki.WriteLine(b);
            fki.WriteLine(c);
            fki.Write(d);
            fki.Close();
        }
    }
}