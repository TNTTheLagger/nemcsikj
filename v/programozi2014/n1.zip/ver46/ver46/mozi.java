import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class mozi {
	static BufferedReader reader;
	static int �l�helySz�m, k�r�sSz�m, K;
	static int[] k�rtSz�kek;
	static int[] alap;
	static ArrayList<Integer> foglalt;
	static ArrayList<Integer> emberek;
	static ArrayList<Integer> jegyek;
	
	static BufferedWriter writer;
	
	public static void main(String[] args) {
		String sor;
		String[] szavak;
		try {
			reader = new BufferedReader(new FileReader("mozi.be"));
			sor = reader.readLine();
			szavak = sor.split(" ");
			
			�l�helySz�m = Integer.parseInt(szavak[0]);
			k�r�sSz�m = Integer.parseInt(szavak[1]);
			K = Integer.parseInt(szavak[2]);
			
			k�rtSz�kek = new int[k�r�sSz�m];
			
			sor = reader.readLine();
			szavak = sor.split(" ");
			for(int i = 0; i < k�r�sSz�m; i++) {
				k�rtSz�kek[i] = Integer.parseInt(szavak[i]);
			}
			
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		sorba();
		test();
		
		try {
			writer = new BufferedWriter(new FileWriter("mozi.ki"));
			writer.write(String.valueOf(megold�s));
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	static int megold�s = 0;
	
	public static void sorba() {
		int csere;
		for(int i = 0; i < k�rtSz�kek.length; i++) {
			for(int  k = 0; k < k�rtSz�kek.length; k++) {
				if(k�rtSz�kek[k] > k�rtSz�kek[i]) {
					csere = k�rtSz�kek[k];
					k�rtSz�kek[k] = k�rtSz�kek[i];
					k�rtSz�kek[i] = csere;
				}
			}
		}
	}
	
	public static void test() {
		foglalt = new ArrayList<Integer>();
		emberek = new ArrayList<Integer>();
		jegyek = new ArrayList<Integer>();
		for(int i = 1; i <= �l�helySz�m; i++) {
			foglaltak();
			test2(i);
		}
		
		if(megold�s > �l�helySz�m) {
			megold�s = �l�helySz�m;
		}
	}
	
	public static void test2(int i) {
		for(int k = 0; k < k�rtSz�kek.length; k++) {
			if(k�rtSz�kek[k] == i) {
				if(!foglalt.contains(k�rtSz�kek[k])) {
					emberek.add(k);
					System.out.print("Ember: " + k);
					jegyek.add(k�rtSz�kek[k]);
					System.out.println(i);
					foglalt.add(k�rtSz�kek[k]);
					k�rtSz�kek[k] = -1000;
					megold�s++;
					return;
				}
			} else {
				for(int t = 1; t <= K; t++) {
					if(k�rtSz�kek[k] + t == i) {
						if(!foglalt.contains((k�rtSz�kek[k] + t))) {
							emberek.add(k + 1);
							System.out.print("Ember: " + k);
							jegyek.add(k�rtSz�kek[k] + t);
							System.out.println((i + t));
							foglalt.add(k�rtSz�kek[k]);
							k�rtSz�kek[k] = -1000;
							megold�s++;
							return;
						}
					}
				}
			}
		}
	}
	
	public static void foglaltak() {
		System.out.print("Foglaltak: ");
		for(int i = 0; i < foglalt.size(); i++) {
			System.out.print(foglalt.get(i));
		}
		System.out.println(" ");
	}
}
