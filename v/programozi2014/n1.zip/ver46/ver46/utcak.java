import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class utcak {
	static BufferedReader reader;
	static BufferedWriter writer;
	static int sorSz�m, oszlopSz�m, jelz�Sz�m;
	static int[][] l�mpaHely;
	static int[] start, c�l;
	static String megold�s;
	static ArrayList<String> ir�nyok;
	
	public static void main(String[] args) {
		String sor;
		String[] szavak;
		try {
			reader = new BufferedReader(new FileReader("utcak.be"));
			sor = reader.readLine();
			szavak = sor.split(" ");
			sorSz�m = Integer.parseInt(szavak[0]);
			oszlopSz�m = Integer.parseInt(szavak[1]);
			jelz�Sz�m = Integer.parseInt(szavak[2]);
			
			l�mpaHely = new int[jelz�Sz�m][4];
			
			for(int i = 0; i < jelz�Sz�m; i++) {
				sor = reader.readLine();
				szavak = sor.split(" ");
				
				l�mpaHely[i][0] = Integer.parseInt(szavak[0]);
				l�mpaHely[i][1] = Integer.parseInt(szavak[1]);
				l�mpaHely[i][2] = Integer.parseInt(szavak[2]);
				l�mpaHely[i][3] = Integer.parseInt(szavak[3]);
			}
			
			start = new int[2];
			c�l = new int[2];
			
			sor = reader.readLine();
			szavak = sor.split(" ");
			start[0] = Integer.parseInt(szavak[0]);
			start[1] = Integer.parseInt(szavak[1]);
			c�l[0] = Integer.parseInt(szavak[2]);
			c�l[1] = Integer.parseInt(szavak[3]);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Amegold();
		
		try {
			writer = new BufferedWriter(new FileWriter("utcak.ki"));
			writer.write("5");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	static int[] hely = {1, 1};
	
	public static void Amegold() {
		ir�nyok = new ArrayList<String>();
		
		if(start[0] < c�l[0]) {
			ir�nyok.add("fel");
			System.out.println("fel");
		}
		if(start[0] > c�l[0]) {
			ir�nyok.add("le");
			System.out.println("le");
		}
		if(start[1] < c�l[1]) {
			ir�nyok.add("jobb");
			System.out.println("jobb");
		}
		if(start[1] > c�l[1]) {
			ir�nyok.add("bal");
			System.out.println("bal");
		}
	}
	
	public static boolean check(int a, int b) {
		for(int i = 0; i < jelz�Sz�m; i++) {
			if(l�mpaHely[i][0] == hely[0] && l�mpaHely[i][1] == hely[1]) {
				if((l�mpaHely[i][2] == a && l�mpaHely[i][3] == b) || (a < 1 || b < 1 || a > sorSz�m || b > oszlopSz�m)) {
					return false;
				} else {
					return true;
				}
			}
		}
		
		return true;
	}
	
	public static void Fel() {
		if(check(hely[0] + 1, hely[1])) {
			
		}
	}
	
	public static void Balra() {
		if(check(hely[0], hely[1] + 1)) {
			
		}
	}
	
	public static void Jobbra() {
		if(check(hely[0], hely[1] - 1)) {
			
		}
	}
	
	public static void Le() {
		if(check(hely[0] - 1, hely[1])) {
			
		}
	}
}
