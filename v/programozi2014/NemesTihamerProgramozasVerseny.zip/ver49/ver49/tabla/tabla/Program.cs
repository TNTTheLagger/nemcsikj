﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace tabla
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader r = new StreamReader("tabla.be");
            int lepesek = Convert.ToInt32(r.ReadLine());
           string junk = r.ReadLine();
            r.Close();
            int[] lepes = new int[lepesek];
            for (int i = 0; i < lepesek; i++)
            {
                lepes[i] = Convert.ToInt32( junk.Split(' ')[i]);
            }
            int []pont = new int[2];
            int []lehetosegek = new int [lepesek];
            int[] cel = new int[lepesek];
            for (int i = 0; i < lepesek; i++ )
            {
                if (lepes[i] == 0)
                {
                    lehetosegek[0]++;
                    lehetosegek[1]--;
                }
                if (lepes[i] == 1)
                {
                    lehetosegek[0]++;
                    lehetosegek[1]++;
                }
                if (lepes[i] == 2)
                {
                    lehetosegek[0]--;
                }
                if (lepes[i] == 3)
                {
                    lehetosegek[1]++;
                }
                if (lepes[i] == 4)
                {
                    lehetosegek[1]--;
                }
            }
            Boolean ok = true;
            while (ok)
            {
                if (lehetosegek[0] < 0) ///BAL
                {
                }


                if (lehetosegek[0] > 0)  ///JOBB
                {
                    if (lehetosegek[1] > 0) ///JOBB
                    {
                    }
                }
            }

            Console.WriteLine(lehetosegek[0]);
            Console.WriteLine(lehetosegek[1]);
            Console.ReadKey();
        }
    }
}
