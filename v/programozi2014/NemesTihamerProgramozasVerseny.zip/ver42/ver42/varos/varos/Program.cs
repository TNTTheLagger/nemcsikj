﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace varos
{
    class Tile
    {
        public static int NC;
        public static int MC;
        public static Tile[,] Tiles;

        public static string[] Dirs = new string[] { "E", "K", "D", "N" };

        public int N;
        public int M;

        public static int GetDirCode(string dir)
        {
            switch (dir)
            {
                case "E":
                    return 1;
                case "K":
                    return 2;
                case "D":
                    return 3;
                case "N":
                    return 4;
                default:
                    return 0;
            }
        }

        public static string GetDirFromTo(Tile from, Tile to)
        {
            if (from.N < to.N)
                return "E";
            if (from.M < to.M)
                return "K";
            if (from.N > to.N)
                return "D";
            if (from.M > to.M)
                return "N";
            return null;
        }

        public static void Build(int n, int m)
        {
            NC = n;
            MC = m;

            Tiles = new Tile[NC + 2, MC + 2];

            for (int i = 1; i <= NC; i++)
            {
                for (int j = 1; j <= MC; j++)
                {
                    Tiles[i, j] = new Tile(i, j);
                }
            }
        }

        public static void BuildRules()
        {
            for (int i = 1; i <= NC; i++)
            {
                for (int j = 1; j <= MC; j++)
                {
                    Tiles[i, j].BuildDirections();
                }
            }
        }

        public void AddRule(string dir, string rule)
        {
            Rules.Add(Tuple.Create(dir, rule));
        }

        public List<Tuple<string, string>> Rules = new List<Tuple<string, string>>();
        public Dictionary<string, List<Tile>> Directions = new Dictionary<string, List<Tile>>();

        public IEnumerable<Tile> CanGoToFromDir(string from = "")
        {
            foreach (var tile in Directions[from])
            {
                yield return tile;
            }
            yield break;
        }

        public Tile TileFromDir(string dir)
        {
            switch (dir)
            {
                case "E":
                    return Tiles[this.N + 1, this.M];
                case "K":
                    return Tiles[this.N, this.M + 1];
                case "D":
                    return Tiles[this.N - 1, this.M];
                case "N":
                    return Tiles[this.N, this.M - 1];
                default:
                    return null;
            }
        }

        private void BuildDirections()
        {
            Dictionary<string, HashSet<string>> temp_dirs = new Dictionary<string, HashSet<string>>();
            temp_dirs[""] = new HashSet<string>();

            foreach (var dir in Dirs)
            {
                temp_dirs[""].Add(dir);
                temp_dirs[dir] = new HashSet<string>();
                foreach (var dir2 in Dirs)
                {
                    temp_dirs[dir].Add(dir2);
                }
            }

            foreach (var rule in Rules)
            {
                if (rule.Item1 == "E")
                {
                    string B = "N";
                    string J = "K";
                    if (rule.Item2 == "BT")
                    {
                        temp_dirs[rule.Item1].Remove(B);
                    }
                    else if (rule.Item2 == "JT")
                    {
                        temp_dirs[rule.Item1].Remove(J);
                    }
                    else if (rule.Item2 == "BK")
                    {
                        temp_dirs[rule.Item1].Clear();
                        temp_dirs[rule.Item1].Add(B);
                    }
                    else if (rule.Item2 == "JK")
                    {
                        temp_dirs[rule.Item1].Clear();
                        temp_dirs[rule.Item1].Add(J);
                    }
                }
                else if (rule.Item1 == "K")
                {
                    string B = "E";
                    string J = "D";
                    if (rule.Item2 == "BT")
                    {
                        temp_dirs[rule.Item1].Remove(B);
                    }
                    else if (rule.Item2 == "JT")
                    {
                        temp_dirs[rule.Item1].Remove(J);
                    }
                    else if (rule.Item2 == "BK")
                    {
                        temp_dirs[rule.Item1].Clear();
                        temp_dirs[rule.Item1].Add(B);
                    }
                    else if (rule.Item2 == "JK")
                    {
                        temp_dirs[rule.Item1].Clear();
                        temp_dirs[rule.Item1].Add(J);
                    }
                }
                else if (rule.Item1 == "D")
                {
                    string B = "K";
                    string J = "N";
                    if (rule.Item2 == "BT")
                    {
                        temp_dirs[rule.Item1].Remove(B);
                    }
                    else if (rule.Item2 == "JT")
                    {
                        temp_dirs[rule.Item1].Remove(J);
                    }
                    else if (rule.Item2 == "BK")
                    {
                        temp_dirs[rule.Item1].Clear();
                        temp_dirs[rule.Item1].Add(B);
                    }
                    else if (rule.Item2 == "JK")
                    {
                        temp_dirs[rule.Item1].Clear();
                        temp_dirs[rule.Item1].Add(J);
                    }
                }
                else if (rule.Item1 == "N")
                {
                    string B = "D";
                    string J = "E";
                    if (rule.Item2 == "BT")
                    {
                        temp_dirs[rule.Item1].Remove(B);
                    }
                    else if (rule.Item2 == "JT")
                    {
                        temp_dirs[rule.Item1].Remove(J);
                    }
                    else if (rule.Item2 == "BK")
                    {
                        temp_dirs[rule.Item1].Clear();
                        temp_dirs[rule.Item1].Add(B);
                    }
                    else if (rule.Item2 == "JK")
                    {
                        temp_dirs[rule.Item1].Clear();
                        temp_dirs[rule.Item1].Add(J);
                    }
                }
            }

            foreach (var value in temp_dirs)
            {
                Directions[value.Key] = value.Value.Select(e => TileFromDir(e)).Where(e => e != null).ToList();
            }
        }

        public Tile(int n, int m)
        {
            this.N = n;
            this.M = m;
        }
    }

    class Program
    {
        static StreamReader input = new StreamReader("varos.be");
        static StreamWriter output = new StreamWriter("varos.ki");

        static bool[, ,] visited = new bool[101, 101, 5];
        static Stack<Tile> best_sol = new Stack<Tile>();

        public static void Walk(Tile current, string from, Tile end, Stack<Tile> stack)
        {
            if (visited[current.N, current.M, Tile.GetDirCode(from)]) return;

            visited[current.N, current.M, Tile.GetDirCode(from)] = true;
            stack.Push(current);

            if(current.N == end.N && current.M == end.M && (best_sol.Count == 0 || best_sol.Count > stack.Count))
            {
                best_sol = new Stack<Tile>(stack.AsEnumerable());
            }

            foreach (var tile in current.CanGoToFromDir(from))
            {
                string dir_to = Tile.GetDirFromTo(current, tile);
                Walk(tile, dir_to, end, stack);
            }

            stack.Pop();
            visited[current.N, current.M, Tile.GetDirCode(from)] = false;
        }

        static void Main(string[] args)
        {
            int N, M, T;
            {
                int[] vals = input.ReadLine().Split(' ').Select(e => int.Parse(e)).ToArray();
                N = vals[0];
                M = vals[1];
                T = vals[2];
            }

            Tile.Build(N, M);

            for (int i = 0; i < T; i++)
            {
                string[] vals = input.ReadLine().Split(' ');
                int n = int.Parse(vals[1]);
                int m = int.Parse(vals[2]);
                Tile.Tiles[n, m].AddRule(vals[0], vals[3]);
            }

            Tile.BuildRules();

            Tile start, end;
            {
                int[] vals = input.ReadLine().Split(' ').Select(e => int.Parse(e)).ToArray();
                start = Tile.Tiles[vals[0], vals[1]];
                end = Tile.Tiles[vals[2], vals[3]];
            }

            input.Close();

            Walk(start, "", end, new Stack<Tile>());

            output.WriteLine(best_sol.Count - 1);

            var list = best_sol.ToList();
            for (int i = 1; i < list.Count; i++)
            {
                output.Write(Tile.GetDirFromTo(list[i - 1], list[i]));
            }
            output.WriteLine();

            output.Close();
        }
    }
}
