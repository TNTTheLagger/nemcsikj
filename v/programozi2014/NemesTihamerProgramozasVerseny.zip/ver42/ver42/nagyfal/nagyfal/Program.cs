﻿/*
 * Készítette a SharpDevelop.
 * Felhasználó: ver42
 * Dátum: 2014.01.11.
 * Idő: 9:09
 * 
 * A sablon megváltoztatásához használja az Eszközök | Beállítások | Kódolás | Szabvány Fejlécek Szerkesztését.
 */
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace nagyfal
{
	class Program
	{
		static StreamReader input = new StreamReader("nagyfal.be");
		static StreamWriter output = new StreamWriter("nagyfal.ki");
        static int N, M;
        static bool[] def = new bool[200];
		struct Interval : IComparable<Interval>
		{
			public int A;
			public int B;
			
			public int New_Defended
			{
				get {
                    int ret = B - A;
                    if (def[A - 1]) ret++;
                    if (def[B + 1]) ret++;
                    return ret;
				}
			}

            public int Length
            {
                get
                {
                    return B - A + 1;
                }
            }
			
			public int CompareTo(Program.Interval other)
			{
                int comp = this.Length.CompareTo(other.Length);
                if (comp == 0)
                {
                    comp = other.New_Defended.CompareTo(this.New_Defended);
                }
                return comp;
			}
			
			public Interval(int a, int b)
			{
				this.A = a;
				this.B = b;
			}
		}

        struct Point : IComparable<Point>
        {
            public int A;

            public int New_Guarded
            {
                get
                {
                    if (A < 0 || N < A) return 0;
                    int a = (def[A - 1] || A == 1) ? 0 : 1;
                    int b = (def[A + 1] || A == N) ? 0 : 1;
                    return a + b;
                }
            }

            public int CompareTo(Point other)
            {
                int comp = other.New_Guarded.CompareTo(this.New_Guarded);
                if (comp == 0)
                    comp = this.A.CompareTo(other.A);
                return comp;
            }

            public static bool operator ==(Point a, Point b)
            {
                return a.A == b.A;
            }

            public static bool operator !=(Point a, Point b)
            {
                return !(a == b);
            }

            public override bool Equals(object obj)
            {
                if(obj is Point)
                    return this == ((Point)obj);
                return false;
            }

            public Point(int a)
            {
                this.A = a;
            }
        }
		
		public static void Main(string[] args)
		{
			
			{
				int[] vals = input.ReadLine().Split(' ').Select(e => int.Parse(e)).ToArray();
				N = vals[0];
				M = vals[1];
			}
			
			int surplus = 0;
			for (int i = 0; i < M; i++) {
				int val = int.Parse(input.ReadLine());
				if(def[val])
					surplus++;
				else
					def[val] = true;
			}
			
			input.Close();
			
			int guarded = 0;
			int defended = 0;
			int new_guarded = 0;
			int new_defended = 0;
			
			bool prev_guarded = false;
			bool prev_defended = false;
			
			List<Interval> undef = new List<Interval>();
			int interval_start = 1;

            List<Point> no_guard = new List<Point>();
			
			for (int i = 1; i <= N; i++) {
				bool cur_guarded = def[i-1] || def[i];
				bool cur_defended = def[i-1] && def[i];
				
				if(prev_guarded && !cur_guarded) guarded++;
				if(prev_defended && !cur_defended) defended++;
				
				prev_guarded = cur_guarded;
				prev_defended = cur_defended;
				
				if(def[i-1] && !def[i])
					interval_start = i;
				if(!def[i-1] && def[i])
					undef.Add(new Interval(interval_start, i-1));
                if (!def[i])
                    no_guard.Add(new Point(i));
			}
            if (prev_guarded)
                guarded++;
            if (prev_defended)
                defended++;
            if(!def[N])
                undef.Add(new Interval(interval_start, N));

            undef.Sort();

            int temp_surp = surplus;
            for (int i = 0; i < undef.Count && temp_surp > 0; i++)
            {
                if (undef[i].Length <= temp_surp)
                {
                    new_defended += undef[i].New_Defended;
                    temp_surp -= undef[i].Length;
                }
                else
                {
                    new_defended += temp_surp;
                    temp_surp = 0;
                }
            }

            temp_surp = surplus;
            bool[] new_def = new bool[200];
            no_guard.Sort();
            for (int i = 0; i < no_guard.Count && temp_surp > 0; i++)
            {
                Point c = no_guard[i];
                if (new_def[c.A - 1] || new_def[c.A + 1] || c.New_Guarded == 0) continue;
                new_def[c.A] = true;

                new_guarded += c.New_Guarded;
                --temp_surp;
            }
			
			output.WriteLine(defended);
			output.WriteLine(guarded);
			output.WriteLine(new_defended);
			output.WriteLine(new_guarded);
			
			output.Close();
		}
	}
}