﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace gepek
{
    struct Job : IComparable<Job>
    {
        public static int _ID = 0;
        public int ID;
        public int Deadline;

        public Job(int deadline)
        {
            ID = ++_ID;
            Deadline = deadline;
        }

        public int CompareTo(Job other)
        {
            int comp = this.Deadline.CompareTo(other.Deadline);
            if (comp == 0)
                comp = this.ID.CompareTo(other.ID);
            return comp;
        }
    }
    class Program
    {
        static StreamReader input = new StreamReader("gepek.be");
        static StreamWriter output = new StreamWriter("gepek.ki");
        static void Main(string[] args)
        {
            int N, M;
            {
                int[] vals = input.ReadLine().Split(' ').Select(e => int.Parse(e)).ToArray();
                N = vals[0];
                M = vals[1];
            }

            int[,] solution = new int[M + 1, 2];

            SortedSet<Job> jobs = new SortedSet<Job>(input.ReadLine().Split(' ').Select(e => int.Parse(e)).Select(e => new Job(e)));

            input.Close();

            List<Job> to_remove = new List<Job>();
            int cur_machine = 0;
            while (jobs.Count > 0)
            {
                cur_machine++;
                int cur_day = 1;
                foreach (var job in jobs)
                {
                    if (cur_day <= job.Deadline)
                    {
                        solution[job.ID, 0] = cur_day;
                        solution[job.ID, 1] = cur_machine;
                        to_remove.Add(job);
                        cur_day++;
                    }
                }

                foreach (var job in to_remove)
                {
                    jobs.Remove(job);
                }
                to_remove.Clear();
            }

            output.WriteLine(cur_machine);
            for (int i = 1; i <= M; i++)
            {
                output.WriteLine("{0} {1}", solution[i, 0], solution[i, 1]);
            }

            output.Close();
        }
    }
}
