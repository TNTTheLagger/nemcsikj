﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace gepek
{
    class Program
    {
        //static List<Munka>[] napok;
        static List<int>[] napok;
        static void Main(string[] args)
        {
            string[] file = File.ReadAllLines("gepek.be");
            string[] temp = file[0].Split(' ');

            int napokSzama = int.Parse(temp[0]);

            napok = new List<int>[napokSzama];
            for (int i = 0; i < napokSzama; i++)
            {
                napok[i] = new List<int>();
            }

            // 
            temp = file[1].Split(' ');
            for (int i = 0; i < temp.Length; i++)
            {
                napok[int.Parse(temp[i])-1].Add(i); 
            }

            // Szükséges gépek számának meghatározása

            int balance = 0;
            int gepekSzama = 1;
            bool kesz = false;
            do
            {
                for (int i = 0; i < napokSzama; i++)
                {
                    if (napok[i].Count == 0)
                        balance += gepekSzama;
                    else
                    {
                        int z = napok[i].Count / (balance + gepekSzama) + 1;
                        if (z > 1)
                        {
                            gepekSzama++;
                            balance = 0;
                            break;
                        }
                    }

                }
                kesz = true;
            } while(!kesz);

            // Sorrend...
            /*int aktualisGep = 1;
            int aktualisNap = 1;
            for (int i = 0; i < napokSzama; i++)
            {
                for (int x = 0; x < napok[i].Count; x++)
                {
                    //napok[i][x]
                }
            }
            */
            // És elfogyott az idő...

            File.WriteAllText("gepek.ki", gepekSzama.ToString());
        }

    }
}
