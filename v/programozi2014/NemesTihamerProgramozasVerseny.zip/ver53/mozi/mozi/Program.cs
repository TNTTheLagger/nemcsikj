﻿/*
 * Készítette a SharpDevelop.
 * Felhasználó: ver53
 * Dátum: 2014.01.11.
 * Idő: 11:45
 * 
 * A sablon megváltoztatásához használja az Eszközök | Beállítások | Kódolás | Szabvány Fejlécek Szerkesztését.
 */
using System;
using System.IO;
namespace mozi
{
	class Program
	{
		public static void Main(string[] args)
		{
			StreamReader be=new StreamReader("mozi.be");
			StreamWriter ki=new StreamWriter("mozi.ki");
			string [] s=be.ReadLine().Split(' ');
			int M=int.Parse(s[0]);
			int N=int.Parse(s[1]);
			int K=int.Parse(s[2]);
			int [] a=new int[M+2];
			int [,] b=new int[N+2,2];
			int [,] c=new int[N+1,2];
			string [] sz=be.ReadLine().Split(' ');
			for(int i=1;i<N+1;i++)
			{
				b[i,0]=int.Parse(sz[i-1]);
				b[i,1]=i;
			}
			int csere=0;
			int csere2=0;
			for(int i=1;i<N+1;i++)
				for(int j=1;j<N+1;j++)
					if(b[i,0]<b[j,0])
					{
						csere=b[j,0];
						b[j,0]=b[i,0];
						b[i,0]=csere;
						csere2=b[j,1];
						b[j,1]=b[i,1];
						b[i,1]=csere2;
					}
			int sorsz=0;
			for(int i=1;i<N+1;i++)
			{
				sorsz=b[i,0];
				if(a[sorsz]==0)
				{
					a[sorsz]++;
					c[i,0]=b[i,0];
					c[i,1]=b[i,1];
				}
				else
					if(a[sorsz+K]==0)
						{
						a[sorsz+K]++;
						c[i,0]=sorsz+K;
						c[i,1]=b[i,1];
						}
			}
			int db=0;
			for(int i=1;i<M+1;i++)
				if(a[i]!=0)
					db++;
			ki.WriteLine(db);
			for(int i=1;i<M+1;i++)
			{
				ki.Write("{0} {1}",c[i,1],c[i,0]);
				ki.WriteLine();
			}
			ki.Close();
			
		}
	}
}