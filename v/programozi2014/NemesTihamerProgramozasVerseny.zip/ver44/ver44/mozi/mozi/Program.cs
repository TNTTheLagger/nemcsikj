﻿/*
 * Készítette a SharpDevelop.
 * Felhasználó: ver44
 * Dátum: 2014.01.11.
 * Idő: 11:21
 * 
 * A sablon megváltoztatásához használja az Eszközök | Beállítások | Kódolás | Szabvány Fejlécek Szerkesztését.
 */
using System;

namespace mozi
{
	class Program
	{
		public static void Main(string[] args)
		{
			
		}
	}
}