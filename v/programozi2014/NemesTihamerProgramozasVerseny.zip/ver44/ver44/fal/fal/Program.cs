﻿/*
 * Készítette a SharpDevelop.
 * Felhasználó: ver44
 * Dátum: 2014.01.11.
 * Idő: 9:08
 * 
 * A sablon megváltoztatásához használja az Eszközök | Beállítások | Kódolás | Szabvány Fejlécek Szerkesztését.
 */
using System;
using System.IO;

namespace fal
{
	class Program
	{
		public static void Main(string[] args)
		{
			StreamReader be = new StreamReader("fal.be");
			StreamWriter ki = new StreamWriter("fal.ki");
			string[] elso = new string[2];
			elso = be.ReadLine().Split(' ');
			int n, m;
			n =  int.Parse(elso[0]);
			m = int.Parse(elso[1]);
			int i = 0;
			string[] orseg = new string[m];
			while(!be.EndOfStream)
			{
				orseg[i] = be.ReadLine();
				i++;
			}
			int[] orsegint = new int[m];
			for(int j = 0; j < m; j++)
			{
				orsegint[j] = int.Parse(orseg[j]);
			}
			Array.Sort(orsegint);
			int[] holvan = new int[n];
			for(int k = 0; k < n; k++) //holvan keressük
			{
				for(int l = 0; l < m; l++) //az orseginten kell végigmenni
				{
					if(orsegint[l] == k) //ha van az orsegintben berakni holvanba
					{
						holvan[k] = orsegint[l];
					}
				}
			}
			int orzott = 0;
			for(int t = 0; t < n; t++)
			{
				if(holvan[t] !=0)
				{
					while(holvan[t] != 0 && t < n-1)
					{
						t++;
					}
					orzott++;
				}
			}
			int vedett = 0;
			for(int z = 0; z < n-1; z++)
			{
				if(holvan[z] != 0 && holvan[z+1] == 0)
				{
					vedett++;
				}
			}
			ki.WriteLine("{0}", orzott-1);
			ki.WriteLine("{0}", vedett);
			ki.Close();
		}
	}
}