﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader sr = new StreamReader("fal.be");
            string line = sr.ReadLine();
            int wallength = 0;
            int sentrycount = 0;
            int gInt = 0;
            int outp1 = 0;
            int outp2 = 0;
            int lth = 0;
            int needed = 0;
            bool nd = false;
            bool watched = false;
            string bstring = "";
            bool strs = false;
            bool[] guarded = new bool[100];
            for (int i = 0;i < line.Length; i++)
            {
                if (Convert.ToString(line[i]) == " ")
                {
                    strs = true;
                    wallength = Convert.ToInt32(bstring);
                    bstring = "";
                }
                else
                {
                    if (strs== true)
                            {
                                bstring += line[i];
                            }
                        else
                            {
                                bstring += line[i];
                            }
                }
                }
            
            strs = false;
            sentrycount = Convert.ToInt32(bstring);
            bstring = "";
            for (int x = 0;x < 100; x++)
            {
                guarded[x] = false;
            }
            for (int i = 0;i < sentrycount; i++)
            {
                bstring = sr.ReadLine();
                gInt= Convert.ToInt32(bstring);
                guarded[gInt] = true;
            }
            for (int i = 0; i < wallength; i++)
            { 
            
              if(guarded[i]==true & guarded[i+1]==true & strs==false) //output 1 begin
                {
                    outp1++;
                    strs = true;            
                }
              if (guarded[i] != true)
                {
                    strs = false;
                }//output 1 end
              if (guarded[i] == true & watched == false) //output 2 begin
                {
                    watched = true;
                }
              if (guarded[i] == false & guarded[i+1] == false & watched == true)
                {
                    watched = false;
                    outp2++;
                }
              if (guarded[i] == false & guarded[i + 1] == false & nd == false) //output 3 begin
              {
                  lth++;
                  
                  nd = true;
                  needed++;
              }
              if (guarded[i] == true)
              {
                  needed++;
                  nd = false;
              } 
              }// output 3 end
            
                outp2++;
            //output 2 end
            StreamWriter sw = new StreamWriter("fal.ki");
            sw.WriteLine(outp1);
            sw.WriteLine(outp2);
            sw.WriteLine(lth);
            sw.Close();
            Console.ReadLine();
            
        }
    }
}
