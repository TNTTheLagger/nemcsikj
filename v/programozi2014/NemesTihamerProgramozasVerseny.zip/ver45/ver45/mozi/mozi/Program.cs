﻿/*
 * Készítette a SharpDevelop.
 * Felhasználó: ver45
 * Dátum: 2014.01.11.
 * Idő: 9:58
 * 
 * A sablon megváltoztatásához használja az Eszközök | Beállítások | Kódolás | Szabvány Fejlécek Szerkesztését.
 */
using System;
using System.IO;

namespace mozi
{
	class Program
	{
		public static void Main(string[] args)
		{
			StreamWriter ki=new StreamWriter("mozi.ki");
			StreamReader be=new StreamReader("mozi.be");
			string [] line;string [] line2;
			int K=0; int M=0; int N=0; int plusz=0;
			line=be.ReadLine().Split(' ');
			M=Convert.ToInt32(line[0]);
			N=Convert.ToInt32(line[1]);
			K=Convert.ToInt32(line[2]);
			int[] a=new int[M];
			int[] b=new int[N];
			int[] c=new int[M];
			int[] d=new int[M];
			line2=be.ReadLine().Split(' ');
			for(int j=0;j<b.Length;j++)
				b[j]=0;
			for(int i=0;i<M;i++)
			{
				a[i]=int.Parse(line2[i]);
			}
			for(int i=0;i<b.Length;i++)
			{
				for(int j=0;j<a.Length;j++)
				{
					if(a[j]==i && b[i]==0)
					{
						b[i]=1; c[i]=i;
					}
					else
						if(a[j]==1 && b[i]==1)
							plusz++;
				}
			}
			
			ki.WriteLine(N-plusz);
			ki.Close();
		}
	}
}