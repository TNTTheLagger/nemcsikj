﻿/*
 * Készítette a SharpDevelop.
 * Felhasználó: ver54
 * Dátum: 2014.01.11.
 * Idő: 9:02
 * 
 * A sablon megváltoztatásához használja az Eszközök | Beállítások | Kódolás | Szabvány Fejlécek Szerkesztését.
 */
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace varos
{
	struct tabla
	{
		public string I;
		public int sor,oszlop;
		public string kod;
		
		public tabla(string i, int s, int o, string k)
		{
			I=i;
			sor=s;
			oszlop=o;
			kod=k;
		}
	}
	
	struct pont
	{
		public int s, o;
		public string h;
		public pont(int S, int O, string H)
		{
			s=S;
			o=O;
			h=H;
		}
	}
	
	class varos
	{
		static int[] param;
		static List<tabla> t;
		static int[] kv;
		
		static List<pont> Q =new List<pont>();
		static int[,] d;
		static pont p;
		
		static int r_sor(int s)
		{
			return param[0]-s+1;
		}
		
		static Tuple<int,int,string> balra(char I)
		{
			switch (I)
			{
				case 'E':
                    return Tuple.Create(0, -1,"N");
                case 'D':
                    return Tuple.Create(0, 1,"K");
                case 'K':
                    return Tuple.Create(-1, 0,"D");
                case 'N':
                    return Tuple.Create(1,0,"E");
                default:
                    return Tuple.Create(0, 0,"");
			}
		}

        static Tuple<int, int, string> jobbra(char I)
        {
            switch (I)
            {
                case 'E':
                    return Tuple.Create(0, 1, "K");
                case 'D':
                    return Tuple.Create(0, -1, "K");
                case 'K':
                    return Tuple.Create(1, 0, "E");
                case 'N':
                    return Tuple.Create(-1, 0, "D");
                default:
                    return Tuple.Create(0, 0, "");
            }
        }

        static string merrevan(int s1, int o1, int s2, int o2, string honnan)
        {
            switch (honnan[0])
            {
                case 'E':
                    if ((o2 - o1) == -1)
                        return "B";
                    else
                        if ((o2 - o1) == 1)
                            return "J";
                        else return "";
                case 'D':
                    if ((o2 - o1) == 1)
                        return "B";
                    else
                        if ((o2 - o1) == -1)
                            return "J";
                        else return "";
                case 'K':
                    if ((s2 - s1) == 1)
                        return "B";
                    else
                        if ((o2 - o1) == -1)
                            return "J";
                        else return "";
                case 'N':
                    if ((s2 - s1) == -1)
                        return "B";
                    else
                        if ((o2 - o1) == 1)
                            return "J";
                        else return "";
            }
            return "";
        }

		public static void Main(string[] args)
		{
			StreamReader fbe = new StreamReader("varos.be");
			param= fbe.ReadLine().Trim().Split(' ').Select(x=> int.Parse(x)).ToArray();
            t = new List<tabla>();
			for (int i=0; i<param[2];i++ ) 
			{
				string[] sor = fbe.ReadLine().Trim().Split(' ').ToArray();
				t.Add(new tabla(sor[0], r_sor(int.Parse(sor[1])),int.Parse(sor[2]),sor[3]));
			}
			kv=fbe.ReadLine().Trim().Split(' ').Select(x=>int.Parse(x)).ToArray();
			fbe.Close();
			kv[0]=r_sor(kv[0]);
			kv[2]=r_sor(kv[0]);
			
			d= new int[param[0]+1,param[1]+1];
			for (int i=1;i<=param[0];i++)
			{
				for(int j=1;j<=param[1];j++)
				{
					Q.Add(new pont(i,j,""));
					d[i,j]=9999;
				}
			}
			p=new pont(kv[0],kv[1],"");
			Q.Remove(p);
			d[kv[0],kv[1]]=0;
			
			//dijkstra
			while(!(p.s==kv[2] && p.o==kv[3]) && Q.Count>0)
			{
				//akt cellara vonatkozo utasitasok kigyujtese h alapjan
				var akt = t.Where(x=> x.sor==p.s && x.oszlop==p.o).ToList();
				
				//van-e kötelező haladási irány?
				var ilyeniranybol = akt.Where(x=>x.I==p.h.ToString()).Select(x=> x.kod).ToList();
				
				//balra KELL fordulni
				if(ilyeniranybol.Contains("BK"))
				{
                    var korr = balra(p.h[0]);
                    if ((1 + d[p.s, p.o]) < d[p.s + korr.Item1, p.o + korr.Item2])
                    {
                        d[p.s + korr.Item1, p.o + korr.Item2] = 1 + d[p.s, p.o];
                        Q.RemoveAll(x => x.s == (p.s + korr.Item1) && x.o == (p.o + korr.Item2));
                        Q.Add(new pont((p.s + korr.Item1), (p.o + korr.Item2), korr.Item3));
                    }
				}
				else
                    if (ilyeniranybol.Contains("JK"))
                    {
                        var korr = jobbra(p.h[0]);
                        if ((1 + d[p.s, p.o]) < d[p.s + korr.Item1, p.o + korr.Item2])
                        {
                            d[p.s + korr.Item1, p.o + korr.Item2] = 1 + d[p.s, p.o];
                            Q.RemoveAll(x => x.s == (p.s + korr.Item1) && x.o == (p.o + korr.Item2));
                            Q.Add(new pont((p.s + korr.Item1), (p.o + korr.Item2), korr.Item3));
                        }
                    }
                    else //nincs kötelező, nézzük hova nem lehet
                    {
                        if (p.o > 1 && d[p.s, p.o - 1] > (1 + d[p.s, p.o]) && !t.Contains(new tabla(p.h, p.s,p.o, ""+"T")))
                        {
                            d[p.s, p.o - 1] = 1 + d[p.s, p.o];
                            Q.RemoveAll(x => x.s == p.s && x.o == (p.o - 1));
                            Q.Add(new pont(p.s, p.o - 1, "N"));
                        }
                        if (p.o < param[1] && d[p.s, p.o + 1] > (1 + d[p.s, p.o]) && !t.Contains(new tabla(p.h, p.s, p.o, "" + "T")))
                        {
                            d[p.s, p.o + 1] = 1 + d[p.s, p.o];
                            Q.RemoveAll(x => x.s == p.s && x.o == (p.o + 1));
                            Q.Add(new pont(p.s, p.o + 1, "K"));
                        }
                        if (p.s > 1 && d[p.s - 1, p.o] > (1 + d[p.s, p.o]) && !t.Contains(new tabla(p.h, p.s, p.o, "" + "T")))
                        {
                            d[p.s - 1, p.o] = 1 + d[p.s, p.o];
                            Q.RemoveAll(x => x.s == (p.s - 1) && x.o == p.o);
                            Q.Add(new pont(p.s - 1, p.o, "E"));
                        }
                        if (p.s < param[0] && d[p.s + 1, p.o] > (1 + d[p.s, p.o]) && !t.Contains(new tabla(p.h, p.s, p.o, "" + "T")))
                        {
                            d[p.s + 1, p.o] = 1 + d[p.s, p.o];
                            Q.RemoveAll(x => x.s == (p.s + 1) && x.o == p.o);
                            Q.Add(new pont(p.s + 1, p.o, "D"));
                        }
                    }

                p = Q.OrderBy(x => d[x.s,x.o]).ToArray()[0];

                Q.Remove(p);
			}

            StreamWriter fki = new StreamWriter("varos.ki");
            fki.WriteLine(d[kv[2],kv[3]]);
            fki.Close();
            //Console.ReadLine();
		}
	}
}