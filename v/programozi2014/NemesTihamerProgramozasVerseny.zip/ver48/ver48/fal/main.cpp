#include <iostream>

using namespace std;

int main()
{
    int N,M;
    cout <<"Add meg az orzott szakaszok szamat : " << <<1<=N<=100<< endl;
    int N endl;
    cout << "Add meg az orhelyek szamat: " << <<1<=M<=100<< endl;
    if 1<=M<=100 ;cout <<Ird ki!<< endl;
     else 1>M>100 ;cout <<Ne �rd ki!<< endl;
    int M endl;

    return 0;
}
