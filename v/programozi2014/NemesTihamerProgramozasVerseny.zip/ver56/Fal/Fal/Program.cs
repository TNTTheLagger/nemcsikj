﻿using System;
using System.IO;

namespace Fal
{
	class Program
	{
		public static int db_vedett, db_orzott, db_plusz, seged;

		public static void orzott(bool[] wall, int length, int a)
		{
			while(wall[a] || wall[a+1])
			{
				a++;
			}
			db_orzott++;
			if(a>length)
			{
				seged=a-1;
			}
			else
			{
				seged=a;
			}
		}
		
		public static void vedett(bool[] wall, int length, int a)
		{
			int szakasz=0;
			while (wall[a])
			{
				szakasz++;
				a++;
			}
			if(szakasz>1)
			{
				db_vedett++;
			}
			if(a>length)
			{
				seged=a-1;
			}
			else
			{
				seged=a;
			}
		}
		
		public static void Main(string[] args)
		{
			StreamReader olvas = new StreamReader("fal.be");
			StreamWriter ir = new StreamWriter("fal.ki");
			int hossz, guarded; 
			string sor = olvas.ReadLine();
			string[] szet = sor.Split(' ');
			hossz = Convert.ToInt32(szet[0]);
			guarded = Convert.ToInt32(szet[1]);
			bool[] fal = new bool[hossz+2];
			bool[] fal_no2 = new bool[hossz+2];
			for(int i = 0;i<guarded;i++)
			{
				sor = olvas.ReadLine();
				fal[Convert.ToInt32(sor)-1] = true;
				fal_no2[Convert.ToInt32(sor)-1] = true;
			}
			//védett
			for(int l=0;l<hossz;l++)
			{
				if(fal[l])
				{
					vedett(fal, hossz, l);
					l = seged;
				}
			}
			//örzött
			for(int i=0;i<hossz;i++)
			{
				if(fal[i])
				{
					orzott(fal, hossz, i);
					i = seged;
				}
				
			}
			//plusz
			for(int i=0;i<hossz-1;i++)
			{
				if(!fal_no2[i] && !fal_no2[i+1])
				{
					fal_no2[i+1] = true;
					db_plusz++;
				}
			}
			ir.WriteLine("{0}\n{1}\n{2}", db_vedett, db_orzott, db_plusz);
			ir.Close();
		}
	}
}