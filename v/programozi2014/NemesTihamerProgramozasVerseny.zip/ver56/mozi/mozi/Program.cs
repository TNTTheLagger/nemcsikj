﻿using System;
using System.IO;

namespace mozi
{
	class Program
	{
		public static void Main(string[] args)
		{
			StreamReader olvas = new StreamReader("mozi.be");
			StreamWriter ir = new StreamWriter("mozi.ki");
			int helyek, elteres, igenyek;
			int foglalt_helyek = 0;
			string sor = olvas.ReadLine();
			string[] szet = sor.Split(' ');
			helyek = Convert.ToInt32(szet[0]);
			igenyek = Convert.ToInt32(szet[1]);
			elteres = Convert.ToInt32(szet[2]);
			bool[] foglalt_e = new bool[helyek];
			bool[] van_e_helye = new bool[igenyek];
			int[] szeretne = new int[igenyek];
			int[] ki_hol_ul = new int[igenyek];
			sor = olvas.ReadLine();
			szet = sor.Split(' ');
			for(int i=0;i<igenyek;i++)
			{
				szeretne[i] = Convert.ToInt32(szet[i]);
			}
			for(int i=0;i<helyek;i++)
			{
				for(int l=0;l<igenyek;l++)
				{
					if(!foglalt_e[i] && !van_e_helye[l])
					{
						if((i+1)-elteres<=0 && szeretne[l] == i+1)
						{
							foglalt_e[i] = true;
							van_e_helye[l] = true;
							ki_hol_ul[l] = i+1;
							foglalt_helyek++;
						}
						else
						{
							if(szeretne[l] <= i+1 && i+1 <= szeretne[l]+elteres)
							{
								foglalt_e[i] = true;
								van_e_helye[l] = true;
								ki_hol_ul[l] = i+1;
								foglalt_helyek++;
							}
						}
					}
				}						
			}
			ir.WriteLine(foglalt_helyek);
			for(int i=0;i<igenyek;i++)
			{
				if(van_e_helye[i])
				{
					ir.WriteLine("{0} {1}", i+1,  ki_hol_ul[i]);
				}
			}
			ir.Close();
		}
	}
}
