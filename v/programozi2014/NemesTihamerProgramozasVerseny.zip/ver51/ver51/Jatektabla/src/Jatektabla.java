import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Jatektabla {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {

			String file_name = "ver51/Jatektabla/bin/tabla.be";

			FileReader file = new FileReader(file_name);
			BufferedReader textReader = new BufferedReader(file);

			FileWriter file2 = new FileWriter("ver51/Jatektabla/bin/tabla.ki");
			BufferedWriter textWriter = new BufferedWriter(file2);

			int meret = 2;
			String[] textData = new String[meret];

			textData = textReader.readLine().split(" ");

			int N = Integer.parseInt(textData[0]);

			textData = textReader.readLine().split(" ");

			Integer[] tomb = new Integer[N];

			textWriter.write(arg0);
			textWriter.newLine();

			textWriter.close();

		} catch (IOException e) {

			System.out.println(e.getMessage());
		}

	}

}
