import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Utcak {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {

			String file_name = "ver51/Utcak/bin/utcak.be";

			FileReader file = new FileReader(file_name);
			BufferedReader textReader = new BufferedReader(file);

			FileWriter file2 = new FileWriter("ver51/Utcak/bin/utcak.ki");
			BufferedWriter textWriter = new BufferedWriter(file2);

			int meret = 2;
			String[] textData = new String[meret];

			textData = textReader.readLine().split(" ");

			int N = Integer.parseInt(textData[0]);
			int M = Integer.parseInt(textData[1]);
			int T = Integer.parseInt(textData[2]);

			textData = textReader.readLine().split(" ");

			Integer[][] tomb = new Integer[N][M];
			
			

			textWriter.write(arg0);
			textWriter.newLine();

			textWriter.close();

		} catch (IOException e) {

			System.out.println(e.getMessage());
		}

	}

}
