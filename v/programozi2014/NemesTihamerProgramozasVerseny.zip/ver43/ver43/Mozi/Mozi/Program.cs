﻿using System;
using System.IO;
using System.Text;



class Program
{
    static void Main()
    {

        //Fájl megnyitása

        StreamReader sr = new StreamReader("mozi.be");
       


        //Első sor betöltése
        string elsos = sr.ReadLine();
        string[] elso = elsos.Split(' ');
        int[] elsosor = new int[3];

        int[] or = new int[3];
        for (int i = 0; i < 3; i++)
        {
            elsosor[i] = Convert.ToInt32(elso[i]);
        }

       int ulohelyek = elsosor[0];
       int igenyek = elsosor[1];
       int k = elsosor[2];

        //masodik sor betöltése

       string masodik = sr.ReadLine();
       string[] ketto = masodik.Split(' ');
      sr.Close();
 int[] s = new int[ketto.Length];

 for (int i = 0; i < ketto.Length; i++)
 {
     s[i] = Convert.ToInt32(ketto[i]);
 }
       
       /*
        for (int i = 0; i < ketto.Length; i++)
       {
           s[i] = Convert.ToInt32(ketto[i]);
           Console.Write(s[i] + " ");
       }

        * */
 int[] s2 = new int[s.Length];

 
        for (int i = 0; i < s2.Length; i++)
 {
    s2[i] = s[i] + k;
    Console.Write(s2[i] + " ");
 }

 Random r = new Random();
 Console.WriteLine();
 int[] s3 = new int[s2.Length];
 
        
        for (int i = 0; i < s.Length; i++)
 {
      s3[i] = r.Next(s[i], s2[i]);
      Console.Write(s3[i] + " ");
 }

 StreamWriter sw = new StreamWriter("mozi.ki");
 sw.WriteLine(ulohelyek);
 sw.Close();

       

        Console.ReadLine();
           
    
    
    
  }
}

