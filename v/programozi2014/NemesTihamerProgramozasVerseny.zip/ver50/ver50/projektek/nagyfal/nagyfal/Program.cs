﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace nagyfal
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader reader = new StreamReader("nagyfal.be");
            string[] sor = reader.ReadLine().Split(' ');
            int N = Convert.ToInt32(sor[0]), M = Convert.ToInt32(sor[1]);
            int[] pont = new int[N];
            for (int i = 0; i < M; i++)
            {
                pont[Convert.ToInt32(reader.ReadLine()) - 1]++;
            }
            int[] fal = new int[N - 1];
            for (int i = 0; i < N - 1; i++)
            {
                if (pont[i] > 0 && pont[i + 1] > 0)
                {
                    fal[i] = 2;
                }
                else if (pont[i] > 0 || pont[i + 1] > 0)
                {
                    fal[i] = 1;
                }
            }
            int vedett = 0, orzott = 0;
            if (fal[0] == 1)
            {
                orzott++;
            }
            else if (fal[0] == 2)
            {
                vedett++;
            }
            for (int i = 1; i < N-1; i++)
            {
                if (fal[i] == 1 && fal[i - 1] == 0)
                {
                    orzott++;
                }
                else if (fal[i] == 2 && fal[i - 1] != 2)
                {
                    vedett++;
                }
            }
            StreamWriter writer = new StreamWriter("nagyfal.ki");
            writer.WriteLine(vedett);
            writer.WriteLine(orzott);
            int[] pont2 = new int[N];
            pont.CopyTo(pont2, 0);
            int tobb = 0;
            for (int i = 0; i < N; i++)
            {
                if (pont[i] > 0)
                {
                    tobb += pont[i] - 1;
                    pont[i] = 1;
                }
            }
            for (int i = 1; i < N - 1; i++)
            {
                if (tobb == 0)
                {
                    break;
                }
                if (pont[i - 1] != 0 && pont[i] == 0 && pont[i + 1] != 0)
                {
                    pont[i] = 1;
                    tobb--;
                }
            }
            for (int i = 1; i < N - 1; i++)
            {
                if (tobb == 0)
                {
                    break;
                }
                if (pont[i] == 0 && (pont[i - 1] != 0 || pont[i + 1] != 0))
                {
                    pont[i] = 1;
                    tobb--;
                }
            }
            for (int i = 1; i < N - 1; i++)
            {
                if (tobb == 0)
                {
                    break;
                }
                if (pont[i] == 0)
                {
                    pont[i] = 1;
                    tobb--;
                }
            }
            int[] fal2 = new int[N - 1];
            for (int i = 0; i < N - 1; i++)
            {
                if (pont[i] > 0 && pont[i + 1] > 0)
                {
                    fal2[i] = 2;
                }
                else if (pont[i] > 0 || pont[i + 1] > 0)
                {
                    fal2[i] = 1;
                }
            }
            writer.WriteLine(fal2.Count<int>(x => x == 2) - fal.Count<int>(x => x == 2));
            pont = pont2;
            tobb = 0;
            for (int i = 0; i < N; i++)
            {
                if (pont[i] > 0)
                {
                    tobb += pont[i] - 1;
                    pont[i] = 1;
                }
            }
            for (int i = 1; i < N - 1; i++)
            {
                if (tobb == 0)
                {
                    break;
                }
                if (fal[i - 1] == 0 && pont[i] == 0 && fal[i] == 0)
                {
                    pont[i] = 1;
                    tobb--;
                }
            }
            for (int i = 1; i < N - 1; i++)
            {
                if (tobb == 0)
                {
                    break;
                }
                if (pont[i] == 0 && (fal[i - 1] == 0 || fal[i] == 0))
                {
                    pont[i] = 1;
                    tobb--;
                }
            }
            fal2 = new int[N - 1];
            for (int i = 0; i < N - 1; i++)
            {
                if (pont[i] > 0 && pont[i + 1] > 0)
                {
                    fal2[i] = 2;
                }
                else if (pont[i] > 0 || pont[i + 1] > 0)
                {
                    fal2[i] = 1;
                }
            }
            int ujorzott = 0;
            for (int i = 0; i < N-1; i++)
            {
                if (fal[i] == 0 && fal2[i] == 1)
                {
                    ujorzott++;
                }
            }
            writer.WriteLine(ujorzott);
            writer.Close();
        }
    }
}
