import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class tabla {
	static BufferedReader reader;
	static BufferedWriter writer;
	
	public static void main(String[] args) {
		try {
			writer = new BufferedWriter(new FileWriter("tabla.ki"));
			writer.write("3");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
