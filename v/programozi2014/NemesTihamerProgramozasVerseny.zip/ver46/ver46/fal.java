import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class fal {
	static BufferedReader reader;
	static int �rhelySz�m, �rs�gSz�m;
	static int[] �r�kHelye;
	
	static BufferedWriter writer;
	
	public static void main(String[] args) {
		String sor;
		String[] szavak;
		try {
			reader = new BufferedReader(new FileReader("fal.be"));
			sor = reader.readLine();
			szavak = sor.split(" ");
			�rhelySz�m = Integer.parseInt(szavak[0]);
			System.out.println("�rhelyek sz�ma: " + �rhelySz�m);
			�rs�gSz�m = Integer.parseInt(szavak[1]);
			System.out.println("�rs�gek sz�ma: " + �rs�gSz�m);
			
			�r�kHelye = new int[�rs�gSz�m + 1];
			
			for(int i = 0; i < �rs�gSz�m; i++) {
				�r�kHelye[i] = Integer.parseInt(reader.readLine());
				System.out.println("�r�k helye: " + �r�kHelye[i]);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		megoldA();
		System.out.println(amegold�s);
		Bmegold();
		megoldC();
		
		try {
			writer = new BufferedWriter(new FileWriter("fal.ki"));
			writer.write(String.valueOf(amegold�s));
			writer.newLine();
			writer.write(String.valueOf(bmegold�s));
			writer.newLine();
			writer.write(String.valueOf(cmegold�s.size()));
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	
	//---------------------------------------------------------------------
	
	static int amegold�s = 0;
	static int darab = 0;
	static int j = 1;
	public static void megoldA() {
		while(j < �rhelySz�m) {
			test2(j, 0);
			if(darab > 1) {
				amegold�s++;
			}
			j++;
		}
	}
	
	
	public static void test2(int hely, int dara) {
		darab = dara;
		for(int i = 0; i < �rs�gSz�m; i++) {
			if(�r�kHelye[i] == hely) {
				darab = darab + 1;
				test2(hely + 1, darab);
				j = j + 1;
			}
		}
	}
	
	
	//-----------------------------------------------------------------
	
	static int bmegold�s = 0;
	public static void Bmegold() {
		boolean benneVan = false;
		int darab = 0;
		
		for(int i = 1; i <= �rhelySz�m; i++) {
			for(int j = 0; j < �rs�gSz�m + 1; j++) {
				if(�r�kHelye[j] == i || �r�kHelye[j] == i + 1) {
					darab = darab + 1;
					benneVan = true;
				}
				
				if(benneVan && j == �rs�gSz�m && darab > 1) {
					darab = 0;
					bmegold�s++;
					benneVan = false;
				}
				
				if(�r�kHelye[j] == i || �r�kHelye[j] == i + 1) {
					j = �rs�gSz�m;
				}
			}
		}
		
		System.out.println(bmegold�s);
	}
	
	//--------------------------------------------
	static ArrayList<Integer> cmegold�s;
	public static void megoldC() {
		cmegold�s = new ArrayList<Integer>();
		for(int i = 1; i <= �rhelySz�m; i++) {
			for(int k = 0; k < �rs�gSz�m; k++) {
				if(�r�kHelye[k] == i || �r�kHelye[k] == (i + 1) && (cmegold�s.contains(i))) {
					cmegold�s.add((i+1));
				}
			}
		}
	}
}
