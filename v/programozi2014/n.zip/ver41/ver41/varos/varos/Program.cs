﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace varos
{
    class Program
    {
        enum Irany
        {
            Nincs = -1,
            E = 270,
            D = 90,
            K = 0,
            N = 180
        }

        enum Tabla
        {
            Nincs,
            JK,
            JT,
            BK,
            BT
        }

        static int sorSzam, oszlopSzam;
        static Kereszt[,] varos;
        static Pont kezdes, vege;

        static void Main(string[] args)
        {
            // BEOLVASÁS
            string[] file = File.ReadAllLines("varos.be");
            string[] temp = file[0].Split(' ');
            sorSzam = int.Parse(temp[0]);
            oszlopSzam = int.Parse(temp[1]);

            int tablakDB = int.Parse(temp[2]);
            varos = new Kereszt[oszlopSzam, sorSzam];
            for (int x = 0; x < varos.GetLength(0); x++)
            {
                for (int y = 0; y < varos.GetLength(1); y++)
                {
                    varos[x, y] = new Kereszt();
                }
            }

            for (int i = 1; i <= tablakDB; i++)
            {
                temp = file[i].Split(' ');
                Irany ir = parseIrany(temp[0]);
                int x = int.Parse(temp[2]);
                int y = int.Parse(temp[1]);
                Tabla t = parseTable(temp[3]);
                varos[x - 1, y - 1].setTabla(ir, t);
            }

            temp = file[1 + tablakDB].Split(' ');
            kezdes = new Pont(int.Parse(temp[1]) - 1, int.Parse(temp[0]) - 1);
            vege = new Pont(int.Parse(temp[3]) - 1, int.Parse(temp[2]) - 1);

            // MEGOLDÁS

            Dictionary<string, bool> holVoltam = new Dictionary<string, bool>();
            string D, E, K, N;
            string rovid = "";
            // Ha kezdés > 0, akkor léphetek N-felé kezdésnek
            if (kezdes.x > 0)
            {
                K = lep(kezdes.x - 1, kezdes.y, "N", holVoltam);
                if (rovid == "" || K.Length < rovid.Length)
                    rovid = K;
            }
            // Ha kezdés < pályaméret, akkor léphetek K-felé kezdésnek
            if (kezdes.x < oszlopSzam - 2)
            {
                N = lep(kezdes.x + 1, kezdes.y, "K", holVoltam);
                if (rovid == "" || N.Length < rovid.Length)
                    rovid = N;
            }
            // ...
            if (kezdes.y > 0)
            {
                D = lep(kezdes.x, kezdes.y - 1, "D", holVoltam);
                if (rovid == "" || D.Length < rovid.Length)
                    rovid = D;
            }
            // ...
            if (kezdes.y < sorSzam - 2)
            {
                E = lep(kezdes.x, kezdes.y + 1, "E", holVoltam);
                if (rovid == "" || E.Length < rovid.Length)
                    rovid = E;
            }

            // Eredmény kiírása
            File.WriteAllText("varos.ki", rovid.Length + "\r\n" + rovid);

        }

        static string lep(int elozoX, int elozoY, Irany i, string eddigiLepes, Dictionary<string, bool> holVoltam)
        {
            switch (i)
            {
                case Irany.D:
                   elozoY -= 1;
                   break;
                case Irany.E:
                   elozoY += 1;
                   break;
                case Irany.N:
                    elozoX -= 1;
                    break;
                case Irany.K:
                    elozoX += 1;
                    break;
                default:
                    break;
            }

            if (elozoX >= 0 && elozoX < oszlopSzam
                && elozoY >= 0 && elozoY < sorSzam)
                return lep(elozoX, elozoY, eddigiLepes, holVoltam);
            else
                return "";
        }

        static string lep(int x, int y, string eddigiLepes, Dictionary<string, bool> holVoltam)
        {
            if (x == vege.x && y == vege.y)
                return eddigiLepes;

            Irany elozoLepes = parseIrany("" + eddigiLepes[eddigiLepes.Length-1]);

            // Ellenőrzöm, voltam-e már ezen a ponton, ugyan ebből az irányból érkezve

            if (holVoltam.ContainsKey("" + x + "-" + y + elozoLepes.ToString()))
                return "";

            Dictionary<string, bool> holVoltamCopy = new Dictionary<string, bool>(holVoltam);
            holVoltamCopy.Add("" + x + "-" + y + elozoLepes.ToString(), true);


            Irany Megfordul = (Irany)(((int)elozoLepes + 180) % 360);
            Irany Jobbra = (Irany)(((int)elozoLepes + 90) % 360);
            Irany Balra = (Irany)(((int)elozoLepes + 270) % 360);

            // Megnézem merre léphetek
            Irany kotelezo = varos[x, y].kotelezoIrany(elozoLepes);
            // Ha van kötelező irány
            if (kotelezo != Irany.Nincs)
            {
                return lep(x, y, kotelezo, eddigiLepes + kotelezo.ToString(), holVoltamCopy);
            }
            // Ha nincs kötelező irány
            else
            {
                string rovid = "";
                string temp = "";
                // Jobbra
                if (varos[x, y].jobbraSzabad(elozoLepes))
                {
                    temp = lep(x, y, Jobbra, eddigiLepes + Jobbra.ToString(), holVoltamCopy);
                    if (rovid == "" || (temp != "" && temp.Length < rovid.Length))
                        rovid = temp;
                }
                // Balra
                if (varos[x, y].balraSzabad(elozoLepes))
                {
                    temp = lep(x, y, Balra, eddigiLepes + Balra.ToString(), holVoltamCopy);
                    if (rovid == "" ||  (temp != "" && temp.Length < rovid.Length))
                        rovid = temp;
                }
                // Egyenesen
                temp = lep(x, y, elozoLepes, eddigiLepes + elozoLepes.ToString(), holVoltamCopy);
                if (rovid == "" ||  (temp != "" && temp.Length < rovid.Length))
                    rovid = temp;
                
                if (rovid == "")
                    return "";
                else
                    return rovid;
            }
            
            
        }

        struct Pont
        {
            public int x, y;
            public Pont(int x, int y)
            {
                this.x = x;
                this.y = y;
            }
        }

        static Irany parseIrany(string irany)
        {
            switch (irany)
            {
                case "E":
                    return Irany.E;
                case "K":
                    return Irany.K;
                case "D":
                    return Irany.D;
                case "N":
                    return Irany.N;
                default:
                    return Irany.Nincs;
            }
        }

        static Tabla parseTable(string tabla)
        {
            switch (tabla)
            {
                case "JK":
                    return Tabla.JK;
                case "BK":
                    return Tabla.BK;
                case "JT":
                    return Tabla.JT;
                case "BT":
                    return Tabla.BT;
                default:
                    return Tabla.Nincs;
            }
        }

        class Kereszt
        {
            Dictionary<Irany, Tabla[]> tablak = new Dictionary<Irany, Tabla[]>();
            public Kereszt()
            {
                tablak[Irany.E] = new Tabla[2];
                tablak[Irany.D] = new Tabla[2];
                tablak[Irany.K] = new Tabla[2];
                tablak[Irany.N] = new Tabla[2];
            }

            public void setTabla(Irany i, Tabla t)
            {
                if (tablak[i][0] == Tabla.Nincs)
                    tablak[i][0] = t;
                else
                    tablak[i][1] = t;
            }

            public Irany kotelezoIrany(Irany i)
            {
                if (tablak[i][0] == Tabla.BK)
                {
                    return (Irany)(Math.Abs((int)i - 90) % 360);
                }
                else if (tablak[i][0] == Tabla.JK)
                {
                    return (Irany)(((int)i + 90) % 360);
                }

                return Irany.Nincs;
            }

            public bool jobbraSzabad(Irany i)   // i irányból érkezve
            {
                if (tablak[i][0] != Tabla.JT && tablak[i][1] != Tabla.JT)
                    return true;

                return false;
            }
            public bool balraSzabad(Irany i)   // i irányból érkezve
            {
                if (tablak[i][0] != Tabla.BT && tablak[i][1] != Tabla.BT)
                    return true;

                return false;
            }
        }

    }
}
