﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace nagyfal
{
    class Program
    {
        static int orhelyekDB;
        static int orsegDB;
        static int[] orhelyek;
        static int feleslegesOr = 0;
        static List<Szakadas> szakadasok = new List<Szakadas>();
        //static List<int> szakadasokHossz = new List<int>();
        static void Main(string[] args)
        {
            // Adatok beolv.
            string[] file = File.ReadAllLines("nagyfal.be");
            string[] temp = file[0].Split(' ');
            orhelyekDB = int.Parse(temp[0]);
            orsegDB = int.Parse(temp[1]);

            orhelyek = new int[orhelyekDB];

            // Őrök helyének tárolása
            for (int i = 1; i < file.Length; i++)
            {
                orhelyek[(int.Parse(file[i])-1)]++;
            }

            // Hány felesleges őr van?
            // Fal folytonosságának feltérképezése
            int aktualSzakadasStart = -1;
            int aktualSzakadasHossz = 0;
            for (int i = 0; i < orhelyekDB; i++)
            {
                if (orhelyek[i] > 1)
                    feleslegesOr += orhelyek[i] - 1;

                if (orhelyek[i] == 0)
                {
                    if (aktualSzakadasStart != -1)
                    {
                        aktualSzakadasHossz++;
                    }
                    else
                    {
                        aktualSzakadasStart = i;
                        aktualSzakadasHossz = 1;
                    }
                }
                else if (aktualSzakadasStart != -1)
                {
                    szakadasok.Add(new Szakadas(aktualSzakadasStart, aktualSzakadasHossz));
                    aktualSzakadasStart = -1;
                    aktualSzakadasHossz = 0;
                }
            }
            // Ha van még könyveletlen szakadás
            if (aktualSzakadasStart != -1)
                szakadasok.Add(new Szakadas(aktualSzakadasStart,aktualSzakadasHossz));

            // Sorbarendezés!
            bool cserelt;
            Szakadas tempSZ;
            do
            {
                cserelt = false;
                for (int i = 0; i < szakadasok.Count-1; i++)
                {
                    if (szakadasok[i].hossz > szakadasok[i + 1].hossz)
                    {
                        tempSZ = szakadasok[i];
                        szakadasok[i] = szakadasok[i + 1];
                        szakadasok[i + 1] = tempSZ;
                        cserelt = true;
                    }
                }
            } while (cserelt);


            // Őrzött, védett falak meghatározása
            bool[] falakOrzott = new bool[orhelyekDB - 1];
            bool[] falakVedett = new bool[orhelyekDB - 1];

            for (int i = 0; i < orhelyekDB-1; i++)
            {
                falakOrzott[i] = isOrzott(i);
                falakVedett[i] = isVedett(i);
            }

            // Szakaszok számának meghat.
            bool orzottSzakasz = false;
            bool vedettSzakasz = false;
            int orzottSzakaszDB = 0;
            int vedettSzakaszDB = 0;
            for (int i = 0; i < orhelyekDB-1; i++)
            {
                // Előző fal őrzött volt-e
                if (orzottSzakasz)
                {
                    // Ha ez nem őrzött
                    if (!falakOrzott[i])
                    {
                        orzottSzakasz = false;
                        orzottSzakaszDB++;
                    }
                }
                // Mostani fal őrzött-e?
                else
                {
                    orzottSzakasz = falakOrzott[i];
                }
                // Előző fal védett volt-e
                if (vedettSzakasz)
                {
                    // Ha ez nem őrzött
                    if (!falakVedett[i])
                    {
                        vedettSzakasz = false;
                        vedettSzakaszDB++;
                    }
                }
                // Mostani fal védett-e?
                else
                {
                    vedettSzakasz = falakVedett[i];
                }
            }
            // Utolsó elemek hozzáadása
            if (orzottSzakasz)
                orzottSzakaszDB++;
            if (vedettSzakasz)
                vedettSzakaszDB++;

           
            // VÉDETT szakaszok lehetőségeinek felmérése
            // Kisméretű ! szakadásokat kell feltölteni
            int vedetteTehetoDB = 0;
            int maradekFeleslegesOr = feleslegesOr;
            for (int i = 0; i < szakadasok.Count; i++)
            {
                vedetteTehetoDB += szakadasok[i].hossz + 1;
                maradekFeleslegesOr -= szakadasok[i].hossz;

                if (maradekFeleslegesOr <= 0)
                {
                    vedetteTehetoDB += maradekFeleslegesOr-1;
                    break;
                }
            }

            // ŐRZŐTTÉ tehető szakaszok lehetőségei
            // NAGYMÉRETŰ szakadásokat kell feltölteni
            int orzotteTehetoDB = 0;
            maradekFeleslegesOr = feleslegesOr;
            for (int i = szakadasok.Count-1; i > 0; i--)
            {
                // Legalább 1 teljes kihasználtságú őr betehető
                if (szakadasok[i].hossz > 3)
                {
                    int x = szakadasok[i].hossz / 3;
                    if (maradekFeleslegesOr >= x)
                    {
                        maradekFeleslegesOr -= x;
                        orzotteTehetoDB += x * 2;
                    }
                    // Ha még van őr, és maradt lehetéges hely 
                    if (maradekFeleslegesOr > 0)
                    {
                        int maradekHely = szakadasok[i].hossz % 3;
                        if (maradekHely > 0)
                        {
                            maradekFeleslegesOr--;
                            orzotteTehetoDB++;
                        }
                    }
                }
                else if (szakadasok[i].hossz > 1)
                {
                    // Csak akkor lehet vele kezdeni valamit, ha a legelső elem, vagy a legutolsó elem is itt van
                    //if (szakadasok[i].start == 0 || szakadasok[i].getEnd() == orhelyekDB)
                    //{
                        orzotteTehetoDB++;
                        feleslegesOr--;
                    //}
                }
                else
                {
                    // Ha kisebbek vannak már csak, mint 2, azokkal nem lehet mit tenni
                    // De nem állhatok meg, mert lehet, hogy kimarad a 0-tól kezdődő szakadás
                    //break;
                }
            }

            // VÉGEREDMÉNY: 
            File.WriteAllText("nagyfal.ki", 
                vedettSzakaszDB + "\r\n" + 
                orzottSzakaszDB+"\r\n" + 
             
                vedetteTehetoDB+"\r\n" + 
                orzotteTehetoDB+"\r\n");
        }

        /// <summary>
        /// Ha az adott falszakasz Védett
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        static bool isVedett(int id)
        {
            if (orhelyek[id] > 0 && orhelyek[id + 1] > 0)
                return true;

            return false;
        }

        /// <summary>
        /// Ha az adott falszakasz Őrzött
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        static bool isOrzott(int id)
        {
            if (orhelyek[id] > 0 || orhelyek[id + 1] > 0)
                return true;

            return false;
        }

        class Szakadas
        {
            public int start;
            public int hossz;
            public Szakadas(int start, int hossz)
            {
                this.start = start;
                this.hossz = hossz;
            }

            public int getEnd()
            {
                return start + hossz;
            }            
        }

    }
}


