﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace lepes
{
    class Program
    {
        enum Irany
        {
            BalraLe = 0,
            KozepLe = 1,
            JobbraLe = 2,
            Fel = 3,
            Balra = 4,
            Jobbra = 5
        }

        //List<GrafPont> graf = new List<GrafPont>();
        static GrafPont nulladikPont;
        static void Main(string[] args)
        {
            // Gráf felépítése
            nulladikPont = buildGraf(null);


            // Hely meghatározása
            //int sor = 0;
            //int kozeptol = 0;
            //string[] file = File.ReadAllLines("lepes.be");
            //file = file[1].Split(' ');
            //for (int i = 0; i < file.Length; i++)
            //{
            //    switch (int.Parse(file[i]))
            //    {
            //        case (int)Irany.BalraLe:
            //            sor++;
            //            kozeptol--;
            //            break;
            //        case (int)Irany.KozepLe:
            //            sor++;
            //            break;
            //        case (int)Irany.JobbraLe:
            //            sor++;
            //            kozeptol++;
            //            break;
            //        case (int)Irany.Fel:
            //            sor--;
            //            break;
            //        case (int)Irany.Balra:
            //            break;
            //        case (int)Irany.Jobbra:
            //            break;
            //        default:
            //            break;
            //    }
            //}
        }

        class GrafPont
        {
            public GrafPont parent;

            public GrafPont leftChild = null;
            public GrafPont midChild = null;
            public GrafPont rightChild = null;

            public int row;
            /// <summary>
            /// 
            /// </summary>
            /// <param name="parent"></param>
            /// <param name="row">Hanyadik sor (0-tól)</param>
            public GrafPont(GrafPont parent, int row)
            {
                this.parent = parent;
                this.row = row;
            }

            public bool hasRightChild()
            {
                return rightChild != null;
            }
            public bool hasLeftChild()
            {
                return leftChild != null;
            }
            public bool hasMidChild()
            {
                return midChild != null;
            }
        }

        static GrafPont buildGraf(GrafPont parent)
        {
            if (parent == null)
            {
                parent = new GrafPont(null, 0);
            }

            GrafPont t = new GrafPont(parent, parent.row + 1);

            if (parent.row < 99)
            {
                t.leftChild    = buildGraf(t);
                t.rightChild   = buildGraf(t);
                t.midChild     = buildGraf(t);
            }

            return parent;
        }
        
        
    }
}

