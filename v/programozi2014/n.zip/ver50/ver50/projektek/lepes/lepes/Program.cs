﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace lepes
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader reader = new StreamReader("lepes.be");
            string[] sor = reader.ReadLine().Split(' ');
            int K = Convert.ToInt32(sor[0]);
            sor = reader.ReadLine().Split(' ');
            int szint = 0, szam = 0;
            for (int i = 0; i < K; i++)
            {
                switch (sor[i])
                {
                    case "0":
                    case "1":
                    case "2":
                        szint++;
                        szam = szam * 3 + Convert.ToInt32(sor[i]);
                        break;
                    case "3":
                        szint--;
                        szam = (szam - szam % 3) / 3;
                        break;
                    case "4":
                        szam--;
                        break;
                    case "5":
                        szam++;
                        break;
                }
            }
            string megoldas = "";
            for (int i = 0; i < szint; i++)
            {
                megoldas = (szam % 3)+ " " + megoldas;
                szam = (szam - szam % 3) / 3;
            }
            StreamWriter writer = new StreamWriter("lepes.ki");
            writer.WriteLine(szint);
            writer.WriteLine(megoldas.Substring(0, megoldas.Length - 1));
            writer.Close();
        }
        enum hely { J, B, K }
    }
}
