﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace gepek
{
    class Program
    {
        static int N, M;
        static void Main(string[] args)
        {
            StreamReader reader = new StreamReader("gepek.be");
            string[] sor = reader.ReadLine().Split(' ');
            N = Convert.ToInt32(sor[0]); M = Convert.ToInt32(sor[1]);
            sor = reader.ReadLine().Split(' ');
            List<Megrendeles> megrendelesek = new List<Megrendeles>();
            for (int i = 0; i < M; i++)
            {
                megrendelesek.Add(new Megrendeles(Convert.ToInt32(sor[i]),i));
            }
            object[] megoldas = new object[]{};
            int[,] gepek;
            for (int p = 0; p < 1000000; p++)
            {
                megoldas = Try(megrendelesek.ToList(), p);
                if ((bool)megoldas[0])
                {
                    break;
                }
            }
            StreamWriter writer = new StreamWriter("gepek.ki");

            writer.WriteLine((int)megoldas[1] + 1);
           gepek = (int[,])megoldas[2];
            for (int i = 0; i < M; i++)
            {
                for (int o = 0; o < N; o++)
                {
                    if (gepek[i,o] != 0)
                    {
                        writer.WriteLine(o + " " + gepek[i,o]);
                        break;
                    }
                }
            }
            writer.Close();
        }

        private static object[] Try(List<Megrendeles> megrendelesek, int p)
        {
            bool kesz = false;
            List<Megrendeles> megrendelesek2 = megrendelesek.ToList();
            for (int i = 0; i < megrendelesek2.Count; i++)
            {
                megrendelesek2[i].hozzaadva = false;
            }
            int[,] megoldas = new int[M,N];
            for (int i = 1; i < N + 1; i++)
            {
                megrendelesek2 = megrendelesek2.FindAll(x => !x.hozzaadva);
                if (megrendelesek2.FindAll(x => x.Hossz < i).Count > 0)
                {
                    break;
                }
                for (int o = 0; o < p + 1; o++)
                {
                    if (megrendelesek2.Count == 0)
                    {
                        kesz = true;
                        break;
                    }
                    Megrendeles t = max(megrendelesek2);
                    megrendelesek2.Find(x => x.Index == t.Index).hozzaadva = true;
                    megoldas[megrendelesek.IndexOf(t),i] = o + 1;
                    megrendelesek2 = megrendelesek2.FindAll(x => !x.hozzaadva);
                }
                if (kesz)
                {
                    break;
                }
            }
            return new object[]{kesz,p,megoldas};
        }
        private static Megrendeles max(List<Megrendeles> megrendelesek)
        {
            int maximum = Int32.MaxValue;
            foreach (Megrendeles t in megrendelesek)
            {
                if (t.Hossz < maximum)
                {
                    maximum = t.Hossz;
                }
            }
            return megrendelesek.Find(x => x.Hossz == maximum);
        }
    }
    class Megrendeles
    {
        public bool hozzaadva = false;
        public int Hossz;
        public int Index;
        public Megrendeles(int hossz, int index)
        {
            Hossz = hossz;
            Index = index;
        }
    }
}
