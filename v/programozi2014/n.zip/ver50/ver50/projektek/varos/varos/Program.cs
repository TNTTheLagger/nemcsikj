﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace varos
{
    class Program
    {
        static int celX, celY;
        static void Main(string[] args)
        {
            StreamReader reader = new StreamReader("varos.be");
            string[] sor = reader.ReadLine().Split(' ');
            int N = Convert.ToInt32(sor[0]), M = Convert.ToInt32(sor[1]), T = Convert.ToInt32(sor[2]);
            List<Keresztezodes> varos = new List<Keresztezodes>();
            for (int y = 1; y < N + 1; y++)
            {
                for (int x = 1; x < M + 1; x++)
                {
                    varos.Add(new Keresztezodes(x, y));
                }
            }
            for (int i = 0; i < T; i++)
            {
                sor = reader.ReadLine().Split(' ');
                varos.Find(x => x.X == Convert.ToInt32(sor[2]) && x.Y == Convert.ToInt32(sor[1])).tablak.Add(new Tabla(sor[0], sor[3]));
            }
            sor = reader.ReadLine().Split(' ');
            int startY = Convert.ToInt32(sor[0]), startX = Convert.ToInt32(sor[1]);
            celY = Convert.ToInt32(sor[2]);
            celX = Convert.ToInt32(sor[3]);
            object[] ut = Ut(startX,startY,varos,new List<Keresztezodes>());
            StreamWriter writer = new StreamWriter("varos.ki");
            writer.WriteLine((int)ut[0]-1);
            writer.WriteLine(((string)ut[1]).Substring(1));
            writer.Close();
        }

        static object[] Ut(int mostX, int mostY, List<Keresztezodes> varos, List<Keresztezodes> volt, string eddigiUt = " ")
        {
            string jottem = eddigiUt.Substring(eddigiUt.Length - 1);
            string J = "", B = "";
            switch (jottem)
            {
                case "N":
                    J = "E";
                    B = "D";
                    mostX--;
                    break;
                case "D":
                    J = "N";
                    B = "K";
                    mostY--;
                    break;
                case "K":
                    J = "D";
                    B = "E";
                    mostX++;
                    break;
                case "E":
                    J = "K";
                    B = "N";
                    mostY++;
                    break;
            }
            if (mostX == celX && mostY == celY)
            {
                return new object[] { eddigiUt.Length, eddigiUt };
            }
            Keresztezodes most = varos.Find(x => x.X == Convert.ToInt32(mostX) && x.Y == Convert.ToInt32(mostY));
            object[] legrovidebb = new object[]{Int32.MaxValue, eddigiUt};
            if (volt.Count(x => x == most) == 0 && most != null)
            {
                volt.Add(most);
                if (most.tablak.Count == 0)
                {
                    legrovidebb = Rovidebb(legrovidebb, Ut(mostX, mostY, varos, volt.ToList(), eddigiUt + "N"));
                    legrovidebb = Rovidebb(legrovidebb, Ut(mostX, mostY, varos, volt.ToList(), eddigiUt + "K"));
                    legrovidebb = Rovidebb(legrovidebb, Ut(mostX, mostY, varos, volt.ToList(), eddigiUt + "D"));
                    legrovidebb = Rovidebb(legrovidebb, Ut(mostX, mostY, varos, volt.ToList(), eddigiUt + "E"));
                }
                else
                {
                    bool tovabbB = true, tovabbJ = true, tovabbegyenes = true;
                    foreach (Tabla tabla in most.tablak)
                    {
                        if (tabla.Irany == jottem)
                        {
                            switch (tabla.Tilos)
                            {
                                case "JK":
                                    tovabbB = false;
                                    tovabbegyenes = false;
                                    break;
                                case "BK":
                                    tovabbJ = false;
                                    tovabbegyenes = false;
                                    break;
                                case "JT":
                                    tovabbJ = false;
                                    break;
                                case "BT":
                                    tovabbB = false;
                                    break;
                            }
                        }
                    }
                    if (tovabbB)
                    {
                        legrovidebb = Rovidebb(legrovidebb, Ut(mostX, mostY, varos, volt.ToList(), eddigiUt + B));
                    }
                    if (tovabbJ)
                    {
                        legrovidebb = Rovidebb(legrovidebb, Ut(mostX, mostY, varos, volt.ToList(), eddigiUt + J));
                    }
                    if (tovabbegyenes)
                    {
                        legrovidebb = Rovidebb(legrovidebb, Ut(mostX, mostY, varos, volt.ToList(), eddigiUt + jottem));
                    }
                }
                volt.Remove(most);
            }
            return legrovidebb;
        }

        static object[] Rovidebb(object[] p1, object[] p2)
        {
            return ((int)p1[0] < (int)p2[0]) ? p1 : p2;
        }
    }
    class Keresztezodes
    {
        public int X = 0;
        public int Y = 0;
        public List<Tabla> tablak;
        public Keresztezodes(int x, int y)
        {
            X = x;
            Y = y;
            tablak = new List<Tabla>();
        }
    }
    class Tabla
    {
        public string Irany;
        public string Tilos;
        public Tabla(string irany, string tilos)
        {
            Irany = irany;
            Tilos = tilos;
        }
    }
}