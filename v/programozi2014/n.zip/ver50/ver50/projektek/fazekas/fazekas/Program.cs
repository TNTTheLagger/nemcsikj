﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace fazekas
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader reader = new StreamReader("fazekas.be");
            string[] sor = reader.ReadLine().Split(' ');
            int N = Convert.ToInt32(sor[0]), K = Convert.ToInt32(sor[1]);
            sor = reader.ReadLine().Split(' ');
            int[] targy = new int[N];
            for (int i = 0; i < N; i++)
            {
                targy[i] = Convert.ToInt32(sor[i]);
            }
            List<string> ki = new List<string>();
            int k1 = 0, k2 = 0;
            int hossz1 = 0, hossz2 = 0;
            int o = 0, s = 0;
            int hossz = 0;
            while (o < N)
            {
                k1 = 0;
                k2 = 0;
                s++;
                hossz1 = targy[o];
                ki.Add(s + " 1");
                o++;
                k1++;
                hossz2 = targy[o];
                ki.Add(s + " 2");
                o++;
                k2++;
                while (o + 2 < N)
                {
                    if (Math.Abs(hossz1 - targy[o]) < Math.Abs(hossz2 - targy[o]) && k1 < K)
                    {
                        ki.Add(s + " 1");
                        hossz1 = (hossz1 > targy[o]) ? hossz1 : targy[o];
                        k1++;
                        o++;
                    }
                    else
                    {
                        if (k2 < K)
                        {
                            ki.Add(s + " 2");
                            hossz2 = (hossz2 > targy[o]) ? hossz2 : targy[o];
                            k2++;
                            o++;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
                hossz += hossz1 + hossz2;
            }
            StreamWriter writer = new StreamWriter("fazekas.ki");
            writer.WriteLine(hossz);
            foreach (string t in ki)
            {
                writer.WriteLine(t);
            }
            writer.Close();
        }
    }
}
