﻿using System;
using System.IO;
using System.Text;


    class Program
    {
        static void Main()
        {
        
            //StreamReader
            StreamReader sr = new StreamReader("tabla.be");
            string lepesszam = sr.ReadLine();
            string lepesektmp = sr.ReadLine();

            //adatok bekérése és tárolása    
            
            string[] lepesek = lepesektmp.Split(' ');
                int[] lepesekint = new int[lepesek.Length];

          
            for (int i = 0; i < lepesek.Length; i++)
			{
                lepesekint[i] = Convert.ToInt32(lepesek[i]);
			}

            sr.Close();


            //Megoldas


            //Eredmeny kiíratása
            StreamWriter sw = new StreamWriter("tabla.ki");
            sw.Close();
        
        }
    }