﻿using System;
using System.IO;
using System.Text;


class Program
{
    static void Main()
    {

        //Fájl megnyitása

        StreamReader sr = new StreamReader("fal.be");



        //Első sor betöltése
        string elsos = sr.ReadLine();
        string[] tmpor = elsos.Split(' ');

        int[] or = new int[2];
        for (int i = 0; i < 2; i++)
        {
            or[i] = Convert.ToInt32(tmpor[i]);
        }

        //Többi adat betöltése
        int[] orseg = new int[or[1]];
        int szamlalo1 = 0;
        while (!sr.EndOfStream)
        {
            orseg[szamlalo1] = Convert.ToInt32(sr.ReadLine());
            ++szamlalo1;
        }
        sr.Close(); //StreamReader lezárva

        int[] orhelyek = new int[or[0]];

       //orhelyek feltöltése
        int ertektmp = 0;

        for (int i = 0; i < orseg.Length; i++)
        {
            ertektmp = orseg[i] - 1;
            orhelyek[ertektmp] = orseg[i];
        }

        //Védett szakaszok
              
     
        int vedett = 0;
        int tmp1 = 0;
        int tmp2 = 0;

        for (int i = 1; i < or[0]; i++)
        {
            
            tmp1 = orhelyek[i] + 1;
            tmp2 = orhelyek[i] - 1;
            
          if (orhelyek[i] < 1)
            if (tmp1 != 0)
                if(tmp2 != 0)
                   ++vedett;

            }
     


        //őrzött

        int orzott = 0;

        //új örségek

        int ujorseg = 0;

        //Eremenyt mentese

        StreamWriter sw = new StreamWriter("fal.ki", true, Encoding.UTF8);
        sw.WriteLine(vedett);
        sw.WriteLine(orzott);
        sw.WriteLine(ujorseg);
        sw.Close(); //StreamWriter lezárva

        Console.WriteLine(vedett);
        Console.WriteLine(orzott);
        Console.WriteLine(ujorseg);
        
        Console.ReadLine();
    }
}

