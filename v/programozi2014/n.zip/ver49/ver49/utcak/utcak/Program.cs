﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
namespace utcak
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader r = new StreamReader("utcak.be");
            string junk;
            int sor;
            int oszlop;
            int tabla;

            int lines = File.ReadAllLines("utcak.be").Count() - 1;

            junk = r.ReadLine();
            sor = Convert.ToInt32(junk.Split(' ')[0]);
            oszlop = Convert.ToInt32(junk.Split(' ')[1]);
            tabla = Convert.ToInt32(junk.Split(' ')[2]);
            int[] start = new int[2];
            int[] cel = new int[2];
            int[,] tablak = new int[lines - 1, 4];
            int[] positon = new int[2];
            for (int i = 0; i < lines; i++ )
            {
                if (i != lines - 1)
                {
                    junk = r.ReadLine();
                    tablak[i,0] = Convert.ToInt32(junk.Split(' ')[0]);
                    tablak[i, 1] = Convert.ToInt32(junk.Split(' ')[1]);
                    tablak[i, 2] = Convert.ToInt32(junk.Split(' ')[2]);
                    tablak[i, 3] = Convert.ToInt32(junk.Split(' ')[3]);
                } else {
                    junk = r.ReadLine();
                    start[0] = Convert.ToInt32(junk.Split(' ')[0]);
                    start[ 1] = Convert.ToInt32(junk.Split(' ')[1]);
                    cel[0] = Convert.ToInt32(junk.Split(' ')[2]);
                    cel[1] = Convert.ToInt32(junk.Split(' ')[3]);
                }
            }
            Boolean Kesz = false;
            Boolean OK = false;
                        Boolean OK2= false;
            positon[0] = start[0];
            positon[1] = start[1];
            string IRANY = "";
            int akadaly = 0;
            int hany = 0;
            OK = true;
            while (Kesz == false)
            {
                if (positon[0] == cel[0] && positon[1] == cel[1])
                {
                    Kesz = true;
                }
                //UTVONAL TERVEZES


                    if (positon[0] != cel[0])
                    {
                        if (positon[0] < cel[0])
                        {
                         if (Elöre(positon, cel, tablak, lines))
                           {

                             positon[0]++;
                             Console.WriteLine(positon[0] + " " + cel[0]);
                             Console.WriteLine(positon[1] + " " + cel[1]);
                             Console.WriteLine();
                           }
                         else
                         {
                             Console.WriteLine("W");
                             if (positon[1] < 3 && Jobbra(positon, cel, tablak, lines) && OK)
                             {
                                 positon[1]++;

                             }
                             else
                             {
                                 OK = !OK;
                             }
                             if (positon[1] > 1 && Balra(positon, cel, tablak, lines) && !OK)
                             {
                                 positon[1]--;

                             }
                             else
                             {
                                 OK = !OK;
                             }
                         }
                    }

                    if (positon[0] > cel[0])
                    {
                    if (Hatra(positon, cel, tablak, lines))
                    {
                        positon[0]--;

                    }
                    else
                    {

                        if (positon[1] < 3 && Jobbra(positon, cel, tablak, lines) &&OK)
                        {
                            positon[1]++;
                        } else {
                            OK = !OK;
                        }
                        if (positon[1] > 1 && Balra(positon, cel, tablak, lines) && !OK)
                        {
                            positon[1]--;
                        }
                        else
                        {
                            OK = !OK;
                        }
                        }
                        
                    }
                    } else{
                        OK = true;
                        if (positon[1] > cel[1]  && Balra(positon, cel, tablak, lines))
                        {
                            positon[1]--;
                        }
                        else
                        {
                            if (positon[0] > 0  && Hatra(positon, cel, tablak, lines) && OK)
                            {
                                positon[0]--;
                            }
                            else
                            {
                                OK = !OK;
                            }

                        }
                    }
                




            }
            
            
            Console.WriteLine(" " + start[0] + " " + start[1] + " " + cel[0] + " " + cel[1]);
            Console.WriteLine(hany);
            Console.WriteLine(IRANY);
            Console.WriteLine(positon[0] + " " + positon[1] + "||" + cel[0] + " " + cel[1]);
            Console.ReadKey();     
        }

        static Boolean Hatra(int[] position, int[] cel, int[,] tablak, int lines)
        {
            Boolean vissza = new Boolean();
            for (int i = 0; i < lines - 1; i++)
            {
                if (((position[0]  == tablak[i, 0] && position[1] == tablak[i, 1])) && ((position[0]-1 == tablak[i, 2] && position[1] == tablak[i, 3])))
                {
                    vissza = false;
                    break;
                } else {
                    vissza = true;
                }

            }

            return vissza;
        }
        static Boolean Elöre(int[] position, int [] cel, int[,] tablak, int lines)
        {
            Boolean vissza = new Boolean();
            for (int i = 0; i < lines - 1; i++)
            {
                if (((position[0] == tablak[i, 0] && position[1] == tablak[i, 1])) && ((position[0] + 1 == tablak[i, 2] && position[1] == tablak[i, 3])))
                {
                    vissza = false;
                    break;
                }
                else
                {
                    vissza = true;
                }
            }

            return vissza;
        }
        static Boolean Jobbra(int[] position, int[] cel, int[,] tablak, int lines)
        {
            Boolean vissza = new Boolean();
            for (int i = 0; i < lines - 1; i++)
            {
                if (((position[0] == tablak[i, 0] && position[1] == tablak[i, 1])) && ((position[0] == tablak[i, 2] && position[1] + 1 == tablak[i, 3])))
                {
                    vissza = false;
                    break;
                }
                else
                {
                    vissza = true;
                }

            }

            return vissza;
        }
        static Boolean Balra(int[] position, int[] cel, int[,] tablak, int lines)
        {
            Boolean vissza = new Boolean();
            for (int i = 0; i < lines - 1; i++)
            {
                if (((position[0] == tablak[i, 0] && position[1] == tablak[i, 1])) && ((position[0]  == tablak[i, 2] && position[1] - 1 == tablak[i, 3])))
                {
                    vissza = false;
                    break;
                }
                else
                {
                    vissza = true;
                }

            }

            return vissza;
        }
    }
}
