﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace mozi
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader r = new StreamReader("mozi.be");
            string junk;
            int M;
            int N;
            int K;
            int max = new int();
            int lines = File.ReadAllLines("mozi.be").Count() - 1;
            junk = r.ReadLine();
            M = Convert.ToInt32(junk.Split(' ')[0]);
            N = Convert.ToInt32(junk.Split(' ')[1]);
            K = Convert.ToInt32(junk.Split(' ')[2]);
            int[] igeny = new int[N];
            int[,,] szekek = new int[N,K,2];
            junk = r.ReadLine();
            for (int i = 0; i < N; i++)
            {
                igeny[i] = Convert.ToInt32(junk.Split(' ')[i]);
            }
            for (int i = 0; i < N; i++)
            {
                for (int b = 0; b < K; b++)
                {
                    if (igeny[i] + b + 1 < M)
                    {
                        szekek[i, b,0 ] = igeny[i] + b + 1;
                        szekek[i, b, 1] = b+1;
                    }
                    else if (igeny[i] + b  < M)
                    {
                        szekek[i, b,0] = igeny[i] + b ;
                        szekek[i, b, 1] = b;
                    } else {
                        szekek[i, b, 0 ] = igeny[i] ;
                        szekek[i, b, 1] =0;
                    }

                }
            }

            Boolean ok = false;
            Boolean ok2 = false;
            int x= 0;
            int y= 1;
            int[,] thesame = new int[N, K];
            int egyformak = 0;
            int[] wich = new int[N];
            int w = 0;
            //Egyformák
            while (!ok)
            {
                if (x < N)
                {
                    while (ok2 == false)
                    {
                        if (y < N)
                        {
                            for (int c = 0; c < K; c++)
                            {
                                if (szekek[x, c, 0] == szekek[y, c, 0])
                                {
                                     if (szekek[x, c, 0]-szekek[x,c,1] == szekek[y, c, 0])
                                {
                                    if (szekek[x, c, 0] - szekek[x, c, 1] == szekek[y, c, 0] - szekek[y, c, 1])
                                    {

                                        thesame[x, c]++;
                                        egyformak++;
                                        wich[w] = szekek[x, c, 0];
                                        w++;
                                    }
                                }
                                }
                            }

                            y++;

                        }
                        else
                        {
                            ok2 = true;
                        }
                    }
                    ok2 = false;
                    y = 1;
                    x++;


                } else{
                    ok = true;
                }
            }

            /// LEGJOBB
            /// 
            x = 0;
            y = 1;

            Console.WriteLine(w);
            Console.WriteLine(wich[0]);
            Console.WriteLine(wich[1]);
            Console.WriteLine(wich[2]);
            Console.ReadKey();
        }
    }
}
