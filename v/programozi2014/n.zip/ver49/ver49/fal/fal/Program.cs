﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace fal
{
    class Program
    {
        static void Main(string[] args)
        {
            string junk;
            int orhely= new int();
            int orseg;
            int orzott = new int();
            int vedett = new int();
            int potlas = new int();

            int lines;
            lines = File.ReadAllLines("fal.be").Count()-1;
            
            StreamReader r = new StreamReader("fal.be");
            junk = r.ReadLine();
            orhely = Convert.ToInt32(junk.Split(' ')[0]);
            orseg = Convert.ToInt32(junk.Split(' ')[1]);
            int[] orzott_t = new int[orhely];
            Boolean[] fal = new Boolean[orhely+1];
            for (int i = 1; i <= orhely; i++)
            {
                fal[i] = false;
            }
            for (int i = 1; i <= lines; i++)
            {
                junk = r.ReadLine();
                fal[Convert.ToInt32(junk)] = true;
            }

            r.Close();
            /// ORZOTT
            Boolean SZAKASZ = false;
            int x = 0;
            for (int i = 1; i <= orhely; i++)
            {
                if (SZAKASZ == true)
                {
                    if (fal[i] != false)
                    {
                        SZAKASZ = false;
                        x++;
                        orzott_t[x] = i;
                    }

                    if (fal[i + 1] != true && fal[i] == false) 
                    {
                        SZAKASZ = false;
                        orzott_t[orzott] = i+1;
                    }
                } else {
                    if ((i + 2 < orhely) && (fal[i] == true && fal[i + 1] == false && fal[i + 2] == true))
                    {
                        SZAKASZ = true;

                        orzott++;
                            orzott_t[x] = i;
                            x++;
                        
                    }

                }


            }



            /// VEDETT
            SZAKASZ = false;
            for (int i = 1; i <= orhely; i++)
            {
                if (SZAKASZ == true)
                {
                    if (fal[i] != true)
                    {
                        SZAKASZ = false;
                    }
                }
                else
                {
                    if ((fal[i] == true && fal[i + 1] == true))
                    {
                        SZAKASZ = true;
                        vedett++;
                    }

                }


            }

            /// POTLAS

            Boolean OK = false;
            SZAKASZ = false;
            for (int i = 1; i <= orhely; i++)
            {
                for (int b = 0; b < x; b++)
                {
                    if (i != orzott_t[b])
                    {
                        OK = true;
                    }
                }
                if ((fal[i] != true && fal[i + 1] != true) && OK == true)
                {
                    SZAKASZ = true;
                    potlas++;
                    OK = false;
                }

            }



                        Console.WriteLine(vedett);
            Console.WriteLine(orzott);
            Console.WriteLine(potlas);


            StreamWriter w = new StreamWriter("fal.ki");
            w.WriteLine(vedett);
            w.WriteLine(orzott);
            w.Write(potlas);
            w.Close();
            Console.ReadKey();
        }
    }
}
