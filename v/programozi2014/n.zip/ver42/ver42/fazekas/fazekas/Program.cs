﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace fazekas
{
    class Program
    {
        static StreamReader input = new StreamReader("fazekas.be");
        static StreamWriter output = new StreamWriter("fazekas.ki");

        static int burn_time(int[] times, int A, int B, int K)
        {
            var sel_times = times.Skip(A).Take(B - A + 1).ToArray();
            Array.Sort(sel_times);
            int B1 = sel_times[sel_times.Length - 1];
            int B2 = sel_times[0];
            if(sel_times.Length > K)
                B2 = sel_times[sel_times.Length - 1 - K];
            return B1 + B2;
        }

        static void burn_time_sep(int[] times, int A, int B, int K, out int B1, out int B2)
        {
            var sel_times = times.Skip(A).Take(B - A + 1).ToArray();
            Array.Sort(sel_times);
            B1 = sel_times[sel_times.Length - 1];
            B2 = sel_times[0];
            if (sel_times.Length > K)
                B2 = sel_times[sel_times.Length - 1 - K];
        }

        static void gen_sol(int N, int[] times, int K, int[] prev, int burn_count, int[,] solution)
        {
            int C = N;
            while (C > 0)
            {
                int B1;
                int B2;
                burn_time_sep(times, prev[C], C, K, out B1, out B2);

                for (int i = prev[C]; i <= C; i++)
                {
                    solution[i, 0] = burn_count;
                    if (times[i] <= B2)
                        solution[i, 1] = 2;
                    else
                        solution[i, 1] = 1;
                }

                --burn_count;
                C = prev[C] - 1;
            }
        }

        static void Main(string[] args)
        {
            int N, K;
            {
                int[] vals = input.ReadLine().Split(' ').Select(e => int.Parse(e)).ToArray();
                N = vals[0];
                K = vals[1];
            }
            int K2 = K * 2;
            int[] times = new int[] { 0 }.Concat(input.ReadLine().Split(' ').Select(e => int.Parse(e))).ToArray();

            input.Close();

            int[] opt = new int[N + 1];
            int[] burn_count = new int[N + 1];
            int[] prev = new int[N + 1];

            for (int i = 2; i <= N; i++)
            {
                opt[i] = int.MaxValue;

                for (int j = 1; j < K2 && i - j > 0; j++)
                {
                    if (i - j == 2) continue;
                    int new_opt = opt[i - j - 1] + burn_time(times, i - j, i, K);
                    if (new_opt < opt[i])
                    {
                        opt[i] = new_opt;
                        burn_count[i] = burn_count[i - j - 1] + 1;
                        prev[i] = i - j;
                    }
                }
            }

            int[,] solution = new int[N + 1, 2];
            gen_sol(N, times, K, prev, burn_count[N], solution);
            output.WriteLine(opt[N]);
            for (int i = 1; i <= N; i++)
            {
                output.WriteLine("{0} {1}", solution[i, 0], solution[i, 1]);
            }
            output.Close();
        }
    }
}
