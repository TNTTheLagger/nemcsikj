﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Numerics;

namespace lepes
{
    class Program
    {
        static StreamReader input = new StreamReader("lepes.be");
        static StreamWriter output = new StreamWriter("lepes.ki");
        static void Main(string[] args)
        {
            int N = int.Parse(input.ReadLine());
            int[] steps = input.ReadLine().Split(' ').Select(e => int.Parse(e)).ToArray();

            int L = 0;
            BigInteger P = 0;
            foreach (var step in steps)
            {
                switch (step)
                {
                    case 0:
                        L++;
                        P = P * 3;
                        break;
                    case 1:
                        L++;
                        P = P * 3 + 1;
                        break;
                    case 2:
                        L++;
                        P = P * 3 + 2;
                        break;
                    case 3:
                        L--;
                        P = P / 3;
                        break;
                    case 4:
                        P--;
                        break;
                    case 5:
                        P++;
                        break;
                    default:
                        break;
                }
            }

            input.Close();

            List<int> least_steps = new List<int>();
            while (L > 0)
            {
                L--;
                least_steps.Add((int)(P % 3));
                P = P / 3;
            }
            least_steps.Reverse();

            output.WriteLine(least_steps.Count);
            output.WriteLine(string.Join(" ", least_steps));

            output.Close();
        }
    }
}
