﻿/*
 * Készítette a SharpDevelop.
 * Felhasználó: ver44
 * Dátum: 2014.01.11.
 * Idő: 11:23
 * 
 * A sablon megváltoztatásához használja az Eszközök | Beállítások | Kódolás | Szabvány Fejlécek Szerkesztését.
 */
using System;
using System.IO;

namespace utcak
{
	class Program
	{
		public static void Main(string[] args)
		{
			StreamReader be = new StreamReader("utcak.be");
			StreamWriter ki = new StreamWriter("utcak.ki");
			string[] elso = be.ReadLine().Split(' ');
			int sor = int.Parse(elso[0]);
			int tabla = int.Parse(elso[1]);
			int oszlop = int.Parse(elso[2]);
			string[,] mezok = new string[sor, oszlop];
			string[] darabol = new string[tabla*4];
			string[,] honnan = new string[sor,oszlop];
			string[,] hova = new string[sor,oszlop];
			while(!be.EndOfStream)
			{
				darabol = be.ReadToEnd().Split(' ');
			
			}
		}
	}
}