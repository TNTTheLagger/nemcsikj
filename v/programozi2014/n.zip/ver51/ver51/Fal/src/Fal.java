import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Fal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {

			String file_name = "ver51/Fal/bin/fal.be";

			FileReader file = new FileReader(file_name);
			BufferedReader textReader = new BufferedReader(file);

			FileWriter file2 = new FileWriter("ver51/Fal/bin/fal.ki");
			BufferedWriter textWriter = new BufferedWriter(file2);

			int meret = 2;
			String[] textData = new String[meret];

			textData = textReader.readLine().split(" ");

			int N = Integer.parseInt(textData[0]);
			int M = Integer.parseInt(textData[1]);

			textData = textReader.readLine().split(" ");

			Integer[] tomb = new Integer[M];

			for (int i = 0; i < M; i++) {
				tomb[i] = 0;
			}

			for (int i = 0; i < M; i++) {

				if (tomb[i] != 0) {
					tomb[i] = 1;
				}

			}
			int kezdo = 0;
			int utolso = 0;
			int ertek = 0;
			int osszeg = 0;

			for (int i = 0; kezdo != 0; i++) {

				if (tomb[i] == 1) {
					kezdo = i;
				}

			}

			for (int i = 0; i > M; i++) {

				if (tomb[i] == 0) {

					utolso = i;

					ertek = utolso - kezdo;

					kezdo = 0;

				}

			}

			if (ertek >= 3) {
				osszeg++;
			}

			textWriter.write(osszeg);
			textWriter.newLine();

			for (int i = 0; i < M; i++) {
				tomb[i] = 0;
			}

			for (int i = 0; i < M; i++) {

				if (tomb[i] != 0) {
					tomb[i] = 1;
				}

			}
			int kezdo2 = 0;
			int utolso2 = 0;
			int ertek2 = 0;
			int osszeg2 = 0;

			for (int i = 0; kezdo2 != 0; i++) {

				if (tomb[i] == 1) {
					kezdo2 = i;
				}

			}

			for (int i = 0; i > M; i++) {

				if (tomb[i] == 0) {

					utolso2 = i;

					ertek2 = utolso2 - kezdo2;

					kezdo2 = 0;

				}

			}

			if (ertek2 >= 2) {
				osszeg2++;
			}

			textWriter.write(osszeg2);
			textWriter.newLine();

			int ertek3 = 0;

			for (int i = 0; i < M; i++) {

				if (tomb(i + 1) == 0 && tomb(i) == 0) {

					ertek3++;

				}

			}

			textWriter.write(ertek3);
			textWriter.newLine();

			textReader.close();
			textWriter.close();

		} catch (IOException e) {

			System.out.println(e.getMessage());
		}

	}

	private static int tomb(int i) {
		return 0;
	}

}
