/**
 * rokSifr - A multicolor-sifr helper that let the first word be colored.
 * 
 * @version		1.5
 * 
 * @license		MIT-style license
 * @author		Djamil Legato <djamil [at] djamil.it>
 * @client		Andy Miller @ Rockettheme
 * @copyright	Author
 */
 eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('2 9=m P({5:{\'k\':\'16\',\'8\':\'O/N.K\',\'4\':\'#D\',\'o\':\'#14\',\'n\':{}},T:3(a){6.M(a);l 6},q:3(){2 a=6;2 b=$p({F:a.5.k,C:a.5.8,A:a.5.4,z:a.5.o},6.5.n);x.13(11(b));l 6}});9.Z(m X);2 Q=3(d,e,f,g){(d.t).s(3(i){2 a="."+d[i]+" "+e;L(!$E(a))l;r(d,e,g);2 b=$p({\'k\':a,\'8\':f,\'4\':$E(a).7(\'4\'),\'o\':$E(a+\' h\').7(\'4\'),\'n\':{J:"",I:$E(a).7(\'H\'),G:c||""}},g);2 c=$$(a+\' a\').7(\'4\');R=m 9(b).q()})};2 r=3(e,f,g){(e.t).s(3(i){2 d="."+e[i]+" "+f;$$(d).S(3(a){a.B(\'U\',\'V\');2 b=a.W(),j=b.y(" ");u=j[0],w=j.12(1).10(" "),v=a.Y;2 c="<h>"+u+"</h> "+w;a.15(v.17(b,c,"g"))})})};',62,70,'||var|function|color|options|this|getStyle|movie|RokSifr||||||||span||temp|selector|return|new|sifr|firstword|merge|build|RokBuildSpans|times|length|first|html|rest|sIFR|split|sSpanColor|sColor|setStyle|sFlashSrc|444444||sSelector|sHoverColor|backgroundColor|sBgColor|sLinkColor|swf|if|setOptions|gsl|js|Class|RokStart|rok|each|initialize|visibility|visible|getText|Options|innerHTML|implement|join|named|slice|replaceElement|FF9900|setHTML|h3|replace'.split('|'),0,{}))