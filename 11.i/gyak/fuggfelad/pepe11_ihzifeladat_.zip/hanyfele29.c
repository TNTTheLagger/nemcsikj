//PEPE. 29. feladat - H�nyf�le.
#include <stdio.h>
#include <string.h>
int hanyfele(char string[255]);
int main()
{
  int b;
  char string[255];
  printf("Add meg a karakterlancot: ");gets(string);
  printf("Beirt karakterlanc: %s\n",string);
  b=hanyfele(string);
  printf("ennyi kulonbozo elem volt: %d",b);
getchar();
return 0;
}
int hanyfele(char string[255])
{ 
  int chartypes=0,a=0;
  int i,j;
  int len=strlen(string);
    for(i=0;i<len;i++)
                       {
                         a=0;
                           for(j=0;j<len;j++)
                               {
                                     if(string[i]==string[j])
        
                                      a=1;
                                      
                                      if(a==0)
                                        chartypes++;
                                        }                              
      }
 return chartypes;
}
