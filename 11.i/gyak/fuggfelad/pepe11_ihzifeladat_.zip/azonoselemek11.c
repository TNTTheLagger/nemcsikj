//PEPE. 11. feladat - Azonos elemek.
#include <stdio.h>
int azonos(char string[10]);
int main()
{
  int b;
  char string[10];
  printf("Irj be 10 karaktert: ");gets(string);
  printf("Beirt karakter: %s\n",string);
  b=azonos(string);
  if(b==1) printf("Volt azonos!");
  else printf("Nem volt azonos!");
getchar();
return 0;  
}
int azonos(char string[10])
{
int a=0;
int i,j;
    for(i=0;i<10;i++)
    {
     for(j=i+1;j<10;j++)
         {
        if(string[j]==string[i])
         a=1;
          }
      }
 return a;
}
