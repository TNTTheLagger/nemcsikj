#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
double t[100];
double szamol(double x, double *y);

int main(int argc, char* argv[])
{
    double i;

    printf("Kerek egy sort!\n");
    scanf(&t);

    printf("A t t�mb tartalma: %s\nHossza: %d\n", t, strlen(t));
    ;

    return 0;
}

double szamol(double x, double *y)
{
double t[100], i, n;
printf("Adj meg az n szamot: %lf", n);
printf("A karakterlanc jobbrol szamitott n-edik eleme: %lf", y[strlen(y)]-n);

if(y[strlen(y)-n]!=n)
printf("A karakterlanc rovidebb mint a megadott szam");



return i++;
}
