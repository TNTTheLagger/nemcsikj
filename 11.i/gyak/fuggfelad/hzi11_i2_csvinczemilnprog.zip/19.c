#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
char puff[100];
int nyelvtan1(char *);
//int szamol(int a);
int main()
{

do{
       printf("Kerek egy sort!\n");
       gets(&puff);
   }
   while(nyelvtan1(puff));

    printf("A puff tartalma: %s\nHossza: %d\n", puff, strlen(puff));
    nyelvtan1(&puff);

    return 0;
}

int nyelvtan1(char *s)
{
    if(s[0]<'A'||s[0]>'Z')
    {
        printf("A mondat nagybetuvel kezdodik!\n");
        return 1;
    }
    if(s[strlen(s)-1]!='.'&&s[strlen(s)-1]!='!'&&s[strlen(s)-1]!='?')
    {
    printf("A mondat ., ! vagy ? jellel vegzodik!!!!\n");
    return 1;
    }
}

/*int szamol(int a)
{
    int i;
    {if(puff[i]==' ')

    printf("A szavak szama: %d");
 }return 1;}
*/
