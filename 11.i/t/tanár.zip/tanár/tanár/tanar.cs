﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace tanár
{
    struct adat
    {
       public int ora;
       public int tanar;
       public int nap;
       public int tantargy;
    }
    class tanar
    {
        static List<adat> orarend= new List<adat>();
        static int n,m,t,h;
        static int[] mega= new int[7];
        static int megb, megc;
        static List<int> megd= new List<int>();
        static void Main(string[] args)
        {
            StreamReader be = new StreamReader("tanár.be");
            StreamWriter ki = new StreamWriter("tanár.ki");
            string seged = be.ReadLine();
            n = Convert.ToInt32(seged.Split()[0]);
            m = Convert.ToInt32(seged.Split()[1]);
            t = Convert.ToInt32(seged.Split()[2]);
            h = Convert.ToInt32(seged.Split()[3]);
          
            
            while (!be.EndOfStream)
            {
                seged = be.ReadLine();
                adat a;
                a.tanar = Convert.ToInt32(seged.Split()[0]);
                a.tantargy = Convert.ToInt32(seged.Split()[1]);
                a.nap = Convert.ToInt32(seged.Split()[2]);
                a.ora = Convert.ToInt32(seged.Split()[3]);
                orarend.Add(a);
                
            }
            be.Close();
            //A
            for(int i=1;i<=5;i++)
            {
                var le=orarend.Where(tt=>tt.nap==i).Select(tt=>tt.tanar).Distinct().Count();
                mega[i]=n-le;
            }
            //B
            megb=0; int lyuk=100;
            for(int i=1;i<=n;i++)//tanárok
            {
                int ly=0;
                for(int j=1;j<=5;j++)//napok
                {
                    try
                    {
                        var elso = orarend.Where(tt => tt.tanar == i).Where(tt => tt.nap == j).OrderBy(tt => tt.ora).Select(tt => tt.ora).First();
                        var utolso = orarend.Where(tt => tt.tanar == i).Where(tt => tt.nap == j).OrderBy(tt => tt.ora).Select(tt => tt.ora).Last();
                        var ossz = orarend.Where(tt => tt.tanar == i).Where(tt => tt.nap == j).Count();
                        if (elso != utolso)
                        {
                            ly += utolso - elso - ossz + 1;
                        }
                    }
                    catch { };

                }
                if (ly<lyuk)
                {
                    lyuk=ly;
                    megb=i;
                }
            }
            //C
            megc=-1;
            for(int i=1;i<=n;i++)
            {
                bool lehet=true;

                for (int j = 1; j <= 5; j++)
                {
                    var le_helyetes = orarend.Where(tt => tt.tanar == i).Where(tt => tt.nap == j);
                    var le_tanar = orarend.Where(tt => tt.tanar == t).Where(tt => tt.nap == j);
                    if ((le_helyetes.Count() == 0) && (le_tanar.Count() > 0))
                    {
                        lehet = false;
                        
                    }
                    else
                    {
                        foreach (var item in le_tanar)
                        {
                            foreach (var item2 in le_helyetes)
                            {
                                if (item.ora == item2.ora)
                                {
                                    lehet = false;
                                    break;
                                }
                            }
                        }
                    }
                }
                if (lehet)
                {
                    megc = i;
                    break;
                }
            }
            //D
            var lekerdez = orarend.Where(tt => tt.tanar == t).Where(tt => tt.nap == h);
            bool mehet = true;
            foreach (var i in lekerdez)
            {
                mehet = false;
                for (int j = 1; j <= n; j++)
                {
                    var tantargyak = orarend.Where(tt => tt.tanar == j).Select(tt => tt.tantargy).Distinct();//milyen tantárgyakat helyetsít
                    var orarend_helyettes = orarend.Where(tt => tt.tanar == j).Where(tt => tt.nap == h);
                    
                    if (tantargyak.Where(tt => tt == i.tantargy).Count() > 0)
                    {
                        bool lehet = true;
                        foreach ( var k in orarend_helyettes)
                        {
                            if (i.ora == k.ora)
                            {
                                lehet = false;
                                break;
                            }
                        }
                        if (lehet)
                        {
                            mehet = true;
                            megd.Add(j);
                            break;
                        }
                    }
                }
            }
            if (!mehet)
            {
                megd.Clear();
            }
            for (int i = 1; i <= 5; i++)
            {
                ki.Write(mega[i]+" ");
            }
            ki.WriteLine();
            ki.WriteLine(megb);
            ki.WriteLine(megc);
            if (megd.Count == 0)
            {
                ki.WriteLine("-1");
            }
            else
            {
                ki.Write(megd.Count);
                foreach (var i in megd)
                {
                    ki.Write(" " + i);
                }
                    ki.WriteLine();
            }

            ki.Close();


        }
    }
}
