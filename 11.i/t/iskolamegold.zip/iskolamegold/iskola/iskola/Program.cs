﻿/*
 * Készítette a SharpDevelop.
 * Felhasználó: ver53
 * Dátum: 2013.01.12.
 * Idő: 11:19
 * 
 * A sablon megváltoztatásához használja az Eszközök | Beállítások | Kódolás | Szabvány Fejlécek Szerkesztését.
 */
using System;
using System.Collections.Generic;
using System.IO;

namespace iskola
{
    class Program
    {
        const int napokdb = 5;
        const int orakdb = 9;

        public static void Main(string[] args)
        {
            int tanardb;
            int tantargydb;
            int tanarTID;
            int[, ,] tanrend = new int[101, napokdb, orakdb];

            using (StreamReader reader = new StreamReader("iskola.be"))
            {
                string line = reader.ReadLine();
                string[] split = line.Split(' ');
                tanardb = int.Parse(split[0]);
                tantargydb = int.Parse(split[1]);
                tanarTID = int.Parse(split[2]) - 1;
                while (!reader.EndOfStream)
                {
                    line = reader.ReadLine();
                    split = line.Split(' ');
                    int tanarID = int.Parse(split[0]);
                    int tantargyID = int.Parse(split[1]);
                    int nap = int.Parse(split[2]);
                    int ora = int.Parse(split[3]);
                    tanrend[tanarID - 1, nap - 1, ora] = tantargyID;
                }
            }

            int[] napTanarDB = MegoldA(tanardb, tantargydb, tanrend);
            int maxTantargy = MegoldB(tanardb, tantargydb, tanrend);
            int maxLyukas = MegoldC(tanardb, tantargydb, tanrend);
            int helyettesit = MegoldD(tanardb, tantargydb, tanrend, tanarTID);

            using (StreamWriter writer = new StreamWriter("iskola.ki"))
            {
            	for (int i = 0; i < napokdb; i++) {
            		if(i > 0)
            			writer.Write(' ');
            		writer.Write(napTanarDB[i]);
            	}
            	writer.WriteLine();
                writer.WriteLine(maxTantargy);
                writer.WriteLine(maxLyukas);
                writer.Write(helyettesit);
            }
        }

        public static int[] MegoldA(int tanardb, int tantargydb, int[, ,] tanrend)
        {
            int[] napok = new int[napokdb];
            for (int tanar = 0; tanar < tanardb; tanar++)
            {
                for (int nap = 0; nap < napokdb; nap++)
                {
                    bool tanit = false;
                    for (int ora = 0; ora < orakdb; ora++)
                    {
                        tanit = tanit || tanrend[tanar, nap, ora] != 0;
                    }
                    if (tanit)
                        napok[nap] += 1;
                }
            }
            return napok;
        }

        public static int MegoldB(int tanardb, int tantargydb, int[, ,] tanrend)
        {
            int[] tantargyak = new int[tantargydb + 1];
            int tantargyMaxID = -1;
            int tantargyMaxNum = 0;
            for (int tanar = 0; tanar < tanardb; tanar++)
            {
                bool[] tanitTantargy = new bool[tantargydb + 1];
                for (int nap = 0; nap < napokdb; nap++)
                {
                    for (int ora = 0; ora < orakdb; ora++)
                    {
                        int tantargy = tanrend[tanar, nap, ora];
                        tanitTantargy[tantargy] = true;
                    }
                }

                for (int tantargy = 1; tantargy < tantargydb + 1; tantargy++)
                {
                    if (tanitTantargy[tantargy])
                        tantargyak[tantargy] += 1;
                }
            }
            for (int i = 1; i < tantargydb + 1; i++)
            {
                if (tantargyak[i] > tantargyMaxNum)
                {
                    tantargyMaxID = i;
                    tantargyMaxNum = tantargyak[i];
                }
            }

            return tantargyMaxID;
        }

        public static int MegoldC(int tanardb, int tantargydb, int[, ,] tanrend)
        {
            int[] lyukasorak = new int[tanardb];
            int lyukasMaxID = -1;
            int lyukasMaxNum = 0;
            for (int tanar = 0; tanar < tanardb; tanar++)
            {
                for (int nap = 0; nap < napokdb; nap++)
                {
                    bool voltmar = false;
                    int lyukas = 0;
                    for (int ora = 0; ora < orakdb; ora++)
                    {
                        int tantargy = tanrend[tanar, nap, ora];
                        bool vanoraja = tantargy != 0;
                        voltmar = voltmar || vanoraja;
                        if (voltmar)
                        {
                            if (vanoraja)
                            {
                                lyukasorak[tanar] += lyukas;
                                lyukas = 0;
                            }
                            else
                            {
                                lyukas += 1;
                            }
                        }
                    }
                }
            }
            for (int i = 0; i < tanardb; i++)
            {
                if (lyukasorak[i] > lyukasMaxNum)
                {
                    lyukasMaxID = i + 1;
                    lyukasMaxNum = lyukasorak[i];
                }
            }

            return lyukasMaxID;
        }

        public static int MegoldD(int tanardb, int tantargydb, int[, ,] tanrend, int tanarTID)
        {
            bool[] helyettesitheti = new bool[tanardb];
            int helyettesíthetiID = -1;
            for (int i = 0; i < helyettesitheti.Length; i++)
            {
                helyettesitheti[i] = true;
            }

            for (int tanar = 0; tanar < tanardb; tanar++)
            {
                for (int nap = 0; nap < napokdb; nap++)
                {
                    for (int ora = 0; ora < orakdb; ora++)
                    {
                        int tantargy = tanrend[tanar, nap, ora];
                        int tanarTtantargy = tanrend[tanarTID, nap, ora];
                        if (tanarTtantargy != 0 && tantargy != 0)
                            helyettesitheti[tanar] = false;
                    }
                }
            }
            for (int i = 0; i < tanardb; i++)
            {
                if (helyettesitheti[i])
                {
                    helyettesíthetiID = i + 1;
                    break;
                }
            }

            return helyettesíthetiID;
        }
    }
}